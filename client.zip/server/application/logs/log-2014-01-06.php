<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-06 21:41:04 --> Config Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:41:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:41:04 --> URI Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Router Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Output Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Security Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Input Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:41:04 --> Language Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Loader Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:41:04 --> Controller Class Initialized
DEBUG - 2014-01-06 21:41:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:41:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:41:14 --> Config Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:41:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:41:14 --> URI Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Router Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Output Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Security Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Input Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:41:14 --> Language Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Loader Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:41:14 --> Controller Class Initialized
DEBUG - 2014-01-06 21:41:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:41:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:41:42 --> Config Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:41:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:41:42 --> URI Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Router Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Output Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Security Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Input Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:41:42 --> Language Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Loader Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:41:42 --> Controller Class Initialized
DEBUG - 2014-01-06 21:41:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:41:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:41:47 --> Config Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:41:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:41:47 --> URI Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Router Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Output Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Security Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Input Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:41:47 --> Language Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Loader Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:41:47 --> Controller Class Initialized
DEBUG - 2014-01-06 21:41:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:41:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:42:55 --> Config Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:42:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:42:55 --> URI Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Router Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Output Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Security Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Input Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:42:55 --> Language Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Loader Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:42:55 --> Controller Class Initialized
DEBUG - 2014-01-06 21:42:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:42:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:06 --> Config Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:44:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:44:06 --> URI Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Router Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Output Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Security Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Input Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:44:06 --> Language Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Loader Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:44:06 --> Controller Class Initialized
DEBUG - 2014-01-06 21:44:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:44:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:18 --> Config Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:44:18 --> URI Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Router Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Output Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Security Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Input Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:44:18 --> Language Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Loader Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:44:18 --> Controller Class Initialized
DEBUG - 2014-01-06 21:44:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:44:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:26 --> Config Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:44:26 --> URI Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Router Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Output Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Security Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Input Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:44:26 --> Language Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Loader Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:44:26 --> Controller Class Initialized
DEBUG - 2014-01-06 21:44:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:44:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:34 --> Config Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:44:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:44:34 --> URI Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Router Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Output Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Security Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Input Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:44:34 --> Language Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Loader Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:44:34 --> Controller Class Initialized
DEBUG - 2014-01-06 21:44:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:44:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:52 --> Config Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:44:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:44:52 --> URI Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Router Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Output Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Security Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Input Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:44:52 --> Language Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Loader Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:44:52 --> Controller Class Initialized
DEBUG - 2014-01-06 21:44:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:44:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:44:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:44:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:44:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:44:53 --> Model Class Initialized
ERROR - 2014-01-06 21:44:53 --> Non-existent class: Data_transfer
DEBUG - 2014-01-06 21:46:34 --> Config Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:46:34 --> URI Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Router Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Output Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Security Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Input Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:46:34 --> Language Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Loader Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:46:34 --> Controller Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:46:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:46:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:46:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:46:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Config Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:46:59 --> URI Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Router Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Output Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Security Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Input Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:46:59 --> Language Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Loader Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:46:59 --> Controller Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:46:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:46:59 --> Model Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:46:59 --> Model Class Initialized
DEBUG - 2014-01-06 21:46:59 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:02 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:02 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:02 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:26 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:26 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:26 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:28 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:28 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:29 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:29 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:33 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:33 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:33 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:33 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:33 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:33 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:34 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:34 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:34 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:34 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:36 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:36 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:36 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:36 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:36 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:36 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:37 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:37 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:37 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:37 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:37 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:37 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:40 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:40 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:40 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:40 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:40 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:40 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:42 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:42 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:42 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:43 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:43 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:43 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:46 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:46 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:46 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:48 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:48 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:48 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:48 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:48 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:48 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:48 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:50 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:50 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:50 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:50 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:50 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:50 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:51 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:51 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:51 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:51 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:51 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:51 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:51 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:52 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:52 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:52 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:52 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:52 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:52 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:52 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:53 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:53 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:53 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:53 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:53 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:53 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:53 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:53 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:53 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:53 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:53 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:53 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:53 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:54 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:54 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:54 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:54 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:54 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:54 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:54 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:55 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:55 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:55 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:55 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:55 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:55 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:55 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:55 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:55 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:55 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:55 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:55 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:55 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:57 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:57 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:57 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:57 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:57 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:57 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:57 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:58 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:58 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:58 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Config Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:48:58 --> URI Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Router Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Output Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Security Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Input Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:48:58 --> Language Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Loader Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:48:58 --> Controller Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:48:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:48:58 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:19 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:19 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:19 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:19 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:19 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:19 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:20 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:20 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:20 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:20 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:20 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:20 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:22 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:22 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:22 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:22 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:22 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:22 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:22 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:49:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:23 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:49:24 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:24 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:24 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:24 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:49:24 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:24 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:24 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:24 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:24 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:49:26 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:26 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:26 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:26 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:26 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:26 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:26 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:26 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:29 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:29 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:29 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:29 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:29 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:49:30 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:30 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:30 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:30 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:30 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:30 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:30 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:30 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Config Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:49:31 --> URI Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Router Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Output Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Security Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Input Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:49:31 --> Language Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Loader Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:49:31 --> Controller Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:49:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:49:31 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:49:31 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:31 --> Model Class Initialized
DEBUG - 2014-01-06 21:49:31 --> DB Transaction Failure
ERROR - 2014-01-06 21:49:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:49:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:50:17 --> Config Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:50:17 --> URI Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Router Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Output Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Security Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Input Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:50:17 --> Language Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Loader Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:50:17 --> Controller Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:50:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Config Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:50:17 --> URI Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Router Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Output Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Security Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Input Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:50:17 --> Language Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Loader Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:50:17 --> Controller Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:50:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:17 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Config Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:50:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:50:18 --> URI Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Router Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Output Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Security Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Input Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:50:18 --> Language Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Loader Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:50:18 --> Controller Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:50:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:50:18 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:50:18 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:18 --> Model Class Initialized
DEBUG - 2014-01-06 21:50:18 --> DB Transaction Failure
ERROR - 2014-01-06 21:50:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:50:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:51:20 --> Config Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:51:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:51:20 --> URI Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Router Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Output Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Security Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Input Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:51:20 --> Language Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Loader Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:51:20 --> Controller Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:51:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:51:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:51:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:51:20 --> Model Class Initialized
DEBUG - 2014-01-06 21:51:20 --> DB Transaction Failure
ERROR - 2014-01-06 21:51:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:51:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:52:07 --> Config Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:52:07 --> URI Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Router Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Output Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Security Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Input Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:52:07 --> Language Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Loader Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:52:07 --> Controller Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:52:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:52:07 --> Model Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:52:07 --> Model Class Initialized
DEBUG - 2014-01-06 21:52:07 --> Model Class Initialized
DEBUG - 2014-01-06 21:52:07 --> DB Transaction Failure
ERROR - 2014-01-06 21:52:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:52:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:53:32 --> Config Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:53:32 --> URI Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Router Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Output Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Security Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Input Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:53:32 --> Language Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Loader Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:53:32 --> Controller Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:53:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:53:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:53:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:53:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:32 --> DB Transaction Failure
ERROR - 2014-01-06 21:53:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:53:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:53:33 --> Config Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:53:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:53:33 --> URI Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Router Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Output Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Security Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Input Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:53:33 --> Language Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Loader Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:53:33 --> Controller Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:53:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:53:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:53:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:53:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:33 --> Model Class Initialized
DEBUG - 2014-01-06 21:53:33 --> DB Transaction Failure
ERROR - 2014-01-06 21:53:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:53:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:54:02 --> Config Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:54:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:54:02 --> URI Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Router Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Output Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Security Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Input Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:54:02 --> Language Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Loader Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:54:02 --> Controller Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:54:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:54:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:54:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:02 --> DB Transaction Failure
ERROR - 2014-01-06 21:54:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:54:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:54:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:54:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:54:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:54:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:54:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:54:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:54:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:54:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:54:23 --> DB Transaction Failure
ERROR - 2014-01-06 21:54:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:54:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:00 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:00 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:00 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:00 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:00 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:00 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:00 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:00 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:00 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:01 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:01 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:01 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:02 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:02 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:02 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:02 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:03 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:03 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:03 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:03 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:03 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:03 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:03 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:03 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:32 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:32 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:32 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:32 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:32 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:32 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:46 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:46 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:46 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:46 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:46 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:46 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:46 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:55:50 --> Config Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:55:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:55:50 --> URI Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Router Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Output Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Security Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Input Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:55:50 --> Language Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Loader Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:55:50 --> Controller Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:55:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:55:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:55:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:50 --> Model Class Initialized
DEBUG - 2014-01-06 21:55:50 --> DB Transaction Failure
ERROR - 2014-01-06 21:55:50 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:55:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:56:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:56:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:56:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:56:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:56:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:56:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:56:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:56:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:56:23 --> DB Transaction Failure
ERROR - 2014-01-06 21:56:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:56:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:57:36 --> Config Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:57:36 --> URI Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Router Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Output Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Security Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Input Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:57:36 --> Language Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Loader Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:57:36 --> Controller Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:57:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:57:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:57:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:57:36 --> Model Class Initialized
DEBUG - 2014-01-06 21:57:36 --> DB Transaction Failure
ERROR - 2014-01-06 21:57:36 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:57:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:58:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:58:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:58:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:58:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:58:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:58:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> DB Transaction Failure
ERROR - 2014-01-06 21:58:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:58:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:58:23 --> Config Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:58:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:58:23 --> URI Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Router Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Output Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Security Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Input Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:58:23 --> Language Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Loader Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:58:23 --> Controller Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:58:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:23 --> DB Transaction Failure
ERROR - 2014-01-06 21:58:23 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:58:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:58:35 --> Config Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:58:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:58:35 --> URI Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Router Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Output Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Security Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Input Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:58:35 --> Language Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Loader Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:58:35 --> Controller Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:58:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:58:35 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:58:35 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:35 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:35 --> DB Transaction Failure
ERROR - 2014-01-06 21:58:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:58:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 21:58:42 --> Config Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 21:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 21:58:42 --> URI Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Router Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Output Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Security Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Input Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 21:58:42 --> Language Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Loader Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 21:58:42 --> Controller Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 21:58:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 21:58:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 21:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 21:58:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:42 --> Model Class Initialized
DEBUG - 2014-01-06 21:58:42 --> DB Transaction Failure
ERROR - 2014-01-06 21:58:42 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 21:58:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 22:00:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:13 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:13 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:13 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:25 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:25 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:25 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:25 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:25 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:25 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:00:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:00:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:00:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:00:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:00:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:00:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:00:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:47 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:47 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:47 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:47 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:47 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:47 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:58 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:58 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:58 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:58 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:58 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:58 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:02:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:02:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:02:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:02:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:02:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:03:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:03:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:03:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:03:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:03:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:03:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:03:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:03:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:03:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:03:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:03:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:03:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:03:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:03:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:03:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:03:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Config Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:03:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:03:40 --> URI Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Router Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Output Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Security Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Input Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:03:40 --> Language Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Loader Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:03:40 --> Controller Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:03:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:03:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:03:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:03:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:07:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:07:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:07:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:07:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:07:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:07:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:07:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:07:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:07:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:07:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:07:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:08:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:08:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:08:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:08:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:08:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:08:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:09:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:09:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:09:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:09:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:09:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:09:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:09:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:09:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:09:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:09:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:09:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:09:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:09:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:09:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:09:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:09:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:10:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:10:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:10:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:10:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:11:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:11:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:11:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:11:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:11:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:37 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:37 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:37 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:37 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:37 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:37 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:12:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:12:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:12:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:12:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:12:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:05 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:05 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:05 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:05 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:05 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:05 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:29 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:29 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:29 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:29 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:29 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:29 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:37 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:37 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:37 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:47 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:47 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:47 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:13:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:13:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:13:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:13:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:13:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:13:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:13:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:13:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:15 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:15 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:15 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:15 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:15 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:15 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:15 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:14:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:14:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:14:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:14:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:14:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:14:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:16:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:16:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:16:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:16:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:16:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:16:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:16:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Config Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:17:23 --> URI Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Router Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Output Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Security Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Input Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:17:23 --> Language Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Loader Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:17:23 --> Controller Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:17:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:17:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Config Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:17:23 --> URI Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Router Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Output Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Security Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Input Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:17:23 --> Language Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Loader Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:17:23 --> Controller Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:17:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:17:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Config Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:17:25 --> URI Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Router Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Output Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Security Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Input Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:17:25 --> Language Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Loader Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:17:25 --> Controller Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:17:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:17:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:17:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:17:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:17:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:17:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:17:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:17:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:17:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:17:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:23 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:23 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:23 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:26 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:26 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:26 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:18:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:18:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:18:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:18:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:18:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Config Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:19:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:19:51 --> URI Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Router Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Output Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Security Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Input Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:19:51 --> Language Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Loader Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:19:51 --> Controller Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:19:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Config Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:19:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:19:51 --> URI Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Router Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Output Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Security Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Input Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:19:51 --> Language Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Loader Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:19:51 --> Controller Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:19:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:19:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:19:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:19:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:19:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:19:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:19:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:19:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:19:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:20:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:20:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:20:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:20:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:20:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:20:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:20:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:20:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:20:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:20:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:20:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:20:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:20:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:20:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:20:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:20:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:20:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:20:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:20:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:21:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:21:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:21:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:21:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:21:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:21:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:21:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:44 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:44 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:44 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:44 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:44 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:44 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:22:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:22:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:22:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:22:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:22:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:44 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:44 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:44 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:23:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:23:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:23:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:23:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:23:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:24:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:24:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:24:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:24:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:24:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:24:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:25:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:25:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:25:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:25:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:25:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:25:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:25:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:25:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:25:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:25:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:25:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:25:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:25:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:25:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:25:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:25:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:25:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:25:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:25:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:26:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:26:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:26:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:26:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:26:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:26:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:26:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:26:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:26:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:26:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:26:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:26:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:26:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:26:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:26:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:26:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:26:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Config Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:26:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:26:23 --> URI Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Router Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Output Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Security Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Input Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:26:23 --> Language Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Loader Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:26:23 --> Controller Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:26:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:26:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:26:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:26:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:27:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:27:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:27:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:27:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:27:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:27:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:27:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:27:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:27:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:27:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:27:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:27:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:27:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:27:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:27:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:27:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:27:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:29:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:29:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:29:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:29:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:29:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:29:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Config Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:29:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:29:16 --> URI Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Router Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Output Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Security Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Input Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:29:16 --> Language Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Loader Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:29:16 --> Controller Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:29:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:29:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:16 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:29:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:29:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:29:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:29:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:29:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:29:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:29:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:29:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:29:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:20 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:20 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:20 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:20 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:26 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:26 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:26 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:26 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:26 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:26 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:27 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:27 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:27 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:27 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:37 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:37 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:37 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:37 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:37 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:37 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:37 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:38 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:38 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:38 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:38 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Config Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:30:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:30:40 --> URI Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Router Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Output Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Security Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Input Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:30:40 --> Language Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Loader Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:30:40 --> Controller Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:30:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:30:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:30:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:30:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:30:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:31:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:31:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:31:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:31:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:31:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:31:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:31:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:31:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:32:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:32:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:32:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:32:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:32:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:32:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Config Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:33:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:33:02 --> URI Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Router Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Output Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Security Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Input Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:33:02 --> Language Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Loader Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:33:02 --> Controller Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:33:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:33:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:33:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:33:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:33:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Output Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Security Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Input Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:33:06 --> Language Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Loader Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:33:06 --> Controller Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:33:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:33:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:33:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:33:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:33:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:33:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:33:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:33:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:33:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:33:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:33:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:23 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:23 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:23 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:23 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:25 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:25 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:25 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:25 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:25 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:25 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:25 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Config Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:34:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:34:58 --> URI Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Router Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Output Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Security Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Input Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:34:58 --> Language Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Loader Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:34:58 --> Controller Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:34:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:34:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:34:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:34:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:35:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:35:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:35:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:35:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:35:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:35:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:35:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Config Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:35:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:35:05 --> URI Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Router Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Output Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Security Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Input Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:35:05 --> Language Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Loader Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:35:05 --> Controller Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:35:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:35:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:35:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:35:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:35:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:35:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:35:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:35:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:35:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:35:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:35:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:35:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:35:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:06 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:06 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:55 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:55 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:55 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:55 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:38:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:38:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:38:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:38:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:38:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:38:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:38:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:38:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:02 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:02 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:02 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:06 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:06 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:06 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:06 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:08 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:08 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:08 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:08 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:39:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:39:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:39:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:39:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:39:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:39:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:39:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:05 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:05 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:05 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:05 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:05 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:05 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:05 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:13 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:13 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:13 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Config Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:40:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:40:52 --> URI Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Router Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Output Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Security Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Input Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:40:52 --> Language Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Loader Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:40:52 --> Controller Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:40:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:40:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:40:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:40:52 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:29 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:29 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:29 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:29 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:43 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:43 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:43 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:41:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:41:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:41:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:41:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:41:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:42:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:42:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:42:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:42:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:42:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:42:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:42:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Config Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:43:18 --> URI Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Router Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Output Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Security Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Input Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:43:18 --> Language Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Loader Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:43:18 --> Controller Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:43:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:43:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:43:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:43:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:18 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Config Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:43:21 --> URI Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Router Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Output Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Security Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Input Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:43:21 --> Language Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Loader Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:43:21 --> Controller Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:43:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:43:21 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:43:21 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:21 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Config Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:43:26 --> URI Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Router Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Output Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Security Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Input Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:43:26 --> Language Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Loader Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:43:26 --> Controller Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:43:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Config Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:43:26 --> URI Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Router Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Output Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Security Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Input Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:43:26 --> Language Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Loader Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:43:26 --> Controller Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:43:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:02 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:02 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:02 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:13 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:13 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:13 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:13 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:13 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:13 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:13 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:40 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:40 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:40 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:42 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:42 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:42 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:42 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:42 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:42 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:43 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:43 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:43 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:46 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:46 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:46 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:46 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:46 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:46 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:46 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:45:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:45:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:45:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:45:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:45:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:45:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:45:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:45:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:28 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:28 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:28 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:28 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:30 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:30 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:30 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:30 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:42 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:42 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:42 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Config Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:47:45 --> URI Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Router Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Output Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Security Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Input Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:47:45 --> Language Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Loader Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:47:45 --> Controller Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:47:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:47:45 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Config Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:48:39 --> URI Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Router Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Output Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Security Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Input Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:48:39 --> Language Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Loader Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:48:39 --> Controller Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:48:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:48:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:48:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:39 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Config Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:48:41 --> URI Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Router Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Output Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Security Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Input Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:48:41 --> Language Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Loader Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:48:41 --> Controller Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:48:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:48:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:48:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:41 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Config Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:48:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:48:43 --> URI Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Router Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Output Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Security Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Input Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:48:43 --> Language Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Loader Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:48:43 --> Controller Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:48:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Config Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:48:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:48:43 --> URI Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Router Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Output Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Security Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Input Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:48:43 --> Language Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Loader Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:48:43 --> Controller Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:48:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:48:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:32 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:32 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:32 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:32 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:34 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:34 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:34 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:34 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:53 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:53 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:53 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:53 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:56 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:56 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:56 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:56 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Config Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:49:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:49:58 --> URI Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Router Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Output Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Security Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Input Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:49:58 --> Language Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Loader Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:49:58 --> Controller Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:49:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:49:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:49:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:49:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:50:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:50:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:50:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:50:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:50:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:50:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:50:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:50:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:50:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:50:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Config Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:50:59 --> URI Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Router Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Output Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Security Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Input Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:50:59 --> Language Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Loader Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:50:59 --> Controller Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:50:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:51:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:51:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:51:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:51:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:51:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:51:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:51:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:51:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:51:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:51:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:51:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:51:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:51:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:11 --> DB Transaction Failure
ERROR - 2014-01-06 22:52:11 --> Query error: Unknown column 'is_shared' in 'field list'
DEBUG - 2014-01-06 22:52:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 22:52:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:54 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:54 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:54 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:54 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:57 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:57 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:57 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:57 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Config Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:52:58 --> URI Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Router Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Output Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Security Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Input Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:52:58 --> Language Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Loader Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:52:58 --> Controller Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:52:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:52:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:52:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:52:58 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:02 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:02 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:02 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:02 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:02 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:02 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:04 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:04 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:04 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:04 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:06 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:06 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:06 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:06 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:07 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:07 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:07 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:07 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:10 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:10 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:10 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:10 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:47 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:47 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:47 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:47 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:50 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:50 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:50 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:50 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:51 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:51 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:51 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Config Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:53:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:53:51 --> URI Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Router Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Output Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Security Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Input Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:53:51 --> Language Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Loader Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:53:51 --> Controller Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:53:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:53:51 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Config Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:54:09 --> URI Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Router Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Output Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Security Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Input Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:54:09 --> Language Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Loader Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:54:09 --> Controller Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:54:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:54:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:54:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:09 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Config Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:54:11 --> URI Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Router Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Output Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Security Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Input Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:54:11 --> Language Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Loader Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:54:11 --> Controller Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:54:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:54:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:54:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:54:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:54:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:54:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Config Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:54:14 --> URI Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Router Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Output Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Security Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Input Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:54:14 --> Language Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Loader Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:54:14 --> Controller Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:54:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:54:14 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:31 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:31 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:31 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:31 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:33 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:33 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:33 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:33 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:35 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:35 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:35 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:35 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:36 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:36 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:36 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:36 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:42 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:42 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:42 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:42 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:43 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:43 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:43 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:43 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:44 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:44 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:44 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Config Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:55:44 --> URI Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Router Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Output Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Security Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Input Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:55:44 --> Language Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Loader Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:55:44 --> Controller Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:55:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:55:44 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:56:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:56:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:56:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:56:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:56:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:56:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:56:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:00 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:00 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:00 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:00 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:01 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:01 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:01 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:01 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Config Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:57:03 --> URI Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Router Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Output Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Security Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Input Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:57:03 --> Language Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Loader Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:57:03 --> Controller Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:57:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:57:03 --> Model Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Config Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:58:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:58:49 --> URI Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Router Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Output Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Security Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Input Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:58:49 --> Language Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Loader Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:58:49 --> Controller Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:58:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:58:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:58:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:58:49 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:12 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:12 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:12 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:12 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:17 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:17 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:17 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:17 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:19 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:19 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:19 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:24 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:24 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:24 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:24 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Config Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 22:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 22:59:48 --> URI Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Router Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Output Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Security Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Input Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 22:59:48 --> Language Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Loader Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 22:59:48 --> Controller Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 22:59:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 22:59:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 22:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 22:59:48 --> Model Class Initialized
DEBUG - 2014-01-06 22:59:48 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:39 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:39 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:39 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:00:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:00:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:00:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:00:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:00:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:54 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:54 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:54 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:56 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:56 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:56 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:56 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:01:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:01:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:01:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:01:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:01:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:01 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:01 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:01 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:01 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:07 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:07 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:07 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:07 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:07 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:07 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:07 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:17 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:17 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:17 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:17 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:17 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:17 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:40 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:40 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:40 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:40 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:40 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:40 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:02:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:02:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:02:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:02:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:02:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:02:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:02:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:10:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:10:54 --> URI Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Router Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Output Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Security Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Input Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:10:54 --> Language Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Loader Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:10:54 --> Controller Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:10:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:10:54 --> URI Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Router Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Output Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Security Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Input Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:10:54 --> Language Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Loader Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:10:54 --> Controller Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:10:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:10:54 --> URI Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Router Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Output Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Security Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Input Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:10:54 --> Language Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Loader Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:10:54 --> Controller Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:10:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:54 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Config Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:10:57 --> URI Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Router Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Output Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Security Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Input Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:10:57 --> Language Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Loader Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:10:57 --> Controller Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:10:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Config Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:10:58 --> URI Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Router Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Output Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Security Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Input Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:10:58 --> Language Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Loader Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:10:58 --> Controller Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:10:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:04 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:04 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:04 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:04 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:04 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:04 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:10 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:10 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:10 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:10 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:10 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:10 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:12 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:12 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:12 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:14 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:14 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:14 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:16 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:16 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:16 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:16 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:16 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:16 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:19 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:19 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:19 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:19 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:19 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:19 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:20 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:20 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:20 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:20 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:20 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:20 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:20 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Config Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:11:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:11:21 --> URI Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Router Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Output Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Security Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Input Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:11:21 --> Language Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Loader Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:11:21 --> Controller Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:11:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:11:21 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:11:21 --> Model Class Initialized
DEBUG - 2014-01-06 23:11:21 --> Model Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Config Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:19:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:19:57 --> URI Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Router Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Output Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Security Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Input Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:19:57 --> Language Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Loader Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:19:57 --> Controller Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:19:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:19:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:19:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:19:57 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:43 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:43 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:43 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:43 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:45 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:45 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:45 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:47 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:47 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:47 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:47 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:47 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:47 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:48 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:48 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:48 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:48 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:52 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:52 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:52 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:52 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:52 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:52 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:53 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:53 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:53 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:53 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:53 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:53 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:53 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:53 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:53 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:53 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:55 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:55 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:55 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:58 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:58 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:58 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Config Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:22:59 --> URI Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Router Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Output Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Security Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Input Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:22:59 --> Language Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Loader Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:22:59 --> Controller Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:22:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:22:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:22:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:22:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:22:59 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:22 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:22 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:22 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:26 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:26 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:26 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:26 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:26 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:26 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:26 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:26 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:26 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:26 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:28 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:28 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:28 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:28 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:28 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:28 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:31 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:31 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:31 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:31 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:31 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:31 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Config Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:27:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:27:33 --> URI Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Router Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Output Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Security Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Input Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:27:33 --> Language Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Loader Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:27:33 --> Controller Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:27:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:27:33 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:27:33 --> Model Class Initialized
DEBUG - 2014-01-06 23:27:33 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Config Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:30:22 --> URI Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Router Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Output Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Security Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Input Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:30:22 --> Language Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Loader Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:30:22 --> Controller Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:30:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Config Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:30:22 --> URI Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Router Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Output Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Security Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Input Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:30:22 --> Language Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Loader Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:30:22 --> Controller Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:30:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Config Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:30:23 --> URI Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Router Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Output Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Security Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Input Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:30:23 --> Language Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Loader Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:30:23 --> Controller Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:30:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:30:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:30:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Config Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:30:25 --> URI Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Router Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Output Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Security Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Input Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:30:25 --> Language Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Loader Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:30:25 --> Controller Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:30:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Config Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:30:25 --> URI Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Router Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Output Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Security Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Input Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:30:25 --> Language Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Loader Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:30:25 --> Controller Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:30:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:30:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Config Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:40:50 --> URI Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Router Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Output Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Security Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Input Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:40:50 --> Language Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Loader Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:40:50 --> Controller Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:40:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-06 23:40:50 --> DB Transaction Failure
ERROR - 2014-01-06 23:40:50 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 23:40:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 23:41:09 --> Config Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:41:09 --> URI Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Router Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Output Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Security Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Input Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:41:09 --> Language Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Loader Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:41:09 --> Controller Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:41:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:41:09 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:41:09 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:09 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Config Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:41:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:41:14 --> URI Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Router Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Output Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Security Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Input Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:41:14 --> Language Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Loader Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:41:14 --> Controller Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:41:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:41:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:41:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Config Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:41:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:41:39 --> URI Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Router Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Output Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Security Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Input Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:41:39 --> Language Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Loader Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:41:39 --> Controller Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:41:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:41:39 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:14 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:14 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:14 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:14 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:15 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:15 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:15 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:15 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:15 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:15 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:16 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:16 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:16 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:16 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:21 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:21 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:21 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:21 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:21 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:21 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:22 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:22 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:22 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:23 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:23 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:23 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:23 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:24 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:24 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:24 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:24 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:24 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:24 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:24 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:24 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:24 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:24 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:25 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:25 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:25 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Config Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:45:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:45:25 --> URI Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Router Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Output Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Security Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Input Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:45:25 --> Language Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Loader Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:45:25 --> Controller Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:45:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:45:25 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Config Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:46:05 --> URI Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Router Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Output Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Security Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Input Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:46:05 --> Language Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Loader Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:46:05 --> Controller Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:46:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:46:05 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:46:05 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:05 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Config Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:46:06 --> URI Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Router Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Output Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Security Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Input Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:46:06 --> Language Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Loader Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:46:06 --> Controller Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:46:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:46:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:46:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:46:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:46:06 --> Model Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Config Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:53:58 --> URI Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Router Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Output Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Security Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Input Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:53:58 --> Language Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Loader Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:53:58 --> Controller Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:53:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:53:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:53:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:53:58 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Config Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:54:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:54:30 --> URI Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Router Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Output Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Security Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Input Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:54:30 --> Language Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Loader Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:54:30 --> Controller Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:54:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:54:30 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:54:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:54:30 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:30 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:30 --> DB Transaction Failure
ERROR - 2014-01-06 23:54:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-06 23:54:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-06 23:54:42 --> Config Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:54:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:54:42 --> URI Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Router Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Output Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Security Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Input Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:54:42 --> Language Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Loader Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:54:42 --> Controller Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:54:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:54:42 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:54:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:54:42 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Model Class Initialized
DEBUG - 2014-01-06 23:54:42 --> Model Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Config Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Hooks Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Utf8 Class Initialized
DEBUG - 2014-01-06 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-06 23:56:03 --> URI Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Router Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Output Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Security Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Input Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-06 23:56:03 --> Language Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Loader Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-06 23:56:03 --> Controller Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-06 23:56:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-06 23:56:03 --> Model Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Database Driver Class Initialized
ERROR - 2014-01-06 23:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-06 23:56:03 --> Model Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Model Class Initialized
DEBUG - 2014-01-06 23:56:03 --> Model Class Initialized
