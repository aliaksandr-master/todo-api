<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-11 20:17:47 --> Config Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:17:47 --> URI Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Router Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Output Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Security Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Input Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:17:47 --> Language Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Loader Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:17:47 --> Controller Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:17:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:17:47 --> Model Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:17:47 --> Model Class Initialized
DEBUG - 2014-01-11 20:17:47 --> Model Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Config Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:17:57 --> URI Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Router Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Output Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Security Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Input Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:17:57 --> Language Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Loader Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:17:57 --> Controller Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:17:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:17:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 20:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:08 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:08 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:08 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:17 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:17 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:17 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:17 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:17 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:17 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:24 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:24 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:24 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:29 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:29 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:29 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:29 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:29 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:29 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:36 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:36 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:36 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:36 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:36 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:36 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Config Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:18:48 --> URI Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Router Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Output Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Security Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Input Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:18:48 --> Language Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Loader Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:18:48 --> Controller Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:18:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-11 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:03 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:03 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:03 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:03 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:03 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:03 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:08 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:08 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:08 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:14 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:14 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:14 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:14 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:14 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:14 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:18 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:18 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:18 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:18 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:18 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:18 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:32 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:32 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:32 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:32 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:32 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:32 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:37 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:37 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:37 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:37 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:37 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:37 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Config Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:20:50 --> URI Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Router Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Output Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Security Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Input Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:20:50 --> Language Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Loader Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:20:50 --> Controller Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:20:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:20:50 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:20:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:20:50 --> Model Class Initialized
DEBUG - 2014-01-11 20:20:50 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Config Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:21:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:21:04 --> URI Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Router Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Output Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Security Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Input Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:21:04 --> Language Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Loader Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:21:04 --> Controller Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:21:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:21:04 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:21:04 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:04 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Config Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:21:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:21:21 --> URI Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Router Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Output Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Security Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Input Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:21:21 --> Language Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Loader Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:21:21 --> Controller Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:21:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:21:21 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:21:21 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:21 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Config Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:21:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:21:24 --> URI Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Router Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Output Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Security Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Input Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:21:24 --> Language Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Loader Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:21:24 --> Controller Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:21:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:21:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:21:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:21:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Config Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:23:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:23:25 --> URI Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Router Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Output Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Security Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Input Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:23:25 --> Language Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Loader Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:23:25 --> Controller Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:23:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:23:25 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:23:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:23:25 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:25 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Config Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:23:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:23:35 --> URI Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Router Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Output Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Security Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Input Class Initialized
DEBUG - 2014-01-11 20:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:23:35 --> Language Class Initialized
ERROR - 2014-01-11 20:23:35 --> Severity: Notice  --> Undefined property: Todo::$load /home/master/Projects/www/kreantis/listslider/server/application/core/MY_Controller.php 14
DEBUG - 2014-01-11 20:23:41 --> Config Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:23:41 --> URI Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Router Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Output Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Security Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Input Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:23:41 --> Language Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Loader Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:23:41 --> Controller Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:23:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:23:41 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:23:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:23:41 --> Model Class Initialized
DEBUG - 2014-01-11 20:23:41 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Config Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:24:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:24:05 --> URI Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Router Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Output Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Security Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Input Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:24:05 --> Language Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Loader Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:24:05 --> Controller Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:24:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Config Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:24:12 --> URI Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Router Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Output Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Security Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Input Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:24:12 --> Language Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Loader Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:24:12 --> Controller Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:24:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:24:12 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:24:12 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:12 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Config Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:24:15 --> URI Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Router Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Output Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Security Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Input Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:24:15 --> Language Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Loader Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:24:15 --> Controller Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:24:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:24:15 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:24:15 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:15 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Config Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:24:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:24:20 --> URI Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Router Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Output Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Security Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Input Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:24:20 --> Language Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Loader Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:24:20 --> Controller Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:24:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:24:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:24:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Config Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:24:38 --> URI Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Router Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Output Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Security Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Input Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:24:38 --> Language Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Loader Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:24:38 --> Controller Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:24:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:24:38 --> Model Class Initialized
DEBUG - 2014-01-11 20:24:38 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:24:38 --> Model Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Config Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:25:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:25:04 --> URI Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Router Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Output Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Security Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Input Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:25:04 --> Language Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Loader Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:25:04 --> Controller Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:25:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:25:04 --> Model Class Initialized
DEBUG - 2014-01-11 20:25:04 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:25:04 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Config Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:28:00 --> URI Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Router Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Output Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Security Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Input Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:28:00 --> Language Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Loader Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:28:00 --> Controller Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:28:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:28:00 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:28:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:28:00 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Config Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:28:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:28:06 --> URI Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Router Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Output Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Security Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Input Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:28:06 --> Language Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Loader Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:28:06 --> Controller Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:28:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:28:06 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:28:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:28:06 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Config Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:28:13 --> URI Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Router Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Output Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Security Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Input Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:28:13 --> Language Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Loader Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:28:13 --> Controller Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:28:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:28:13 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:28:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:28:13 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Config Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:28:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:28:20 --> URI Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Router Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Output Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Security Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Input Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:28:20 --> Language Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Loader Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:28:20 --> Controller Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:28:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:28:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:28:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Config Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:28:24 --> URI Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Router Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Output Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Security Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Input Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:28:24 --> Language Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Loader Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:28:24 --> Controller Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:28:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:28:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:28:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:08 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:08 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:08 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:16 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:16 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:16 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:16 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:16 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:28 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:28 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:28 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:28 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:28 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:30 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:30 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:30 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:30 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:30 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:39 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:39 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:39 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:39 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:39 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:39 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Config Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:40:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:40:59 --> URI Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Router Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Output Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Security Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Input Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:40:59 --> Language Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Loader Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:40:59 --> Controller Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:40:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:40:59 --> Model Class Initialized
DEBUG - 2014-01-11 20:40:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:40:59 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Config Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:41:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:41:08 --> URI Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Router Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Output Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Security Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Input Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:41:08 --> Language Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Loader Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:41:08 --> Controller Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:41:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:41:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:41:08 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Config Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:41:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:41:20 --> URI Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Router Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Output Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Security Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Input Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:41:20 --> Language Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Loader Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:41:20 --> Controller Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:41:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:41:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:41:20 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Config Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:41:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:41:24 --> URI Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Router Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Output Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Security Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Input Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:41:24 --> Language Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Loader Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:41:24 --> Controller Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:41:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:41:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:41:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:41:24 --> Model Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Config Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:42:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:42:31 --> URI Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Router Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Output Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Security Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Input Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:42:31 --> Language Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Loader Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:42:31 --> Controller Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:42:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:42:31 --> Model Class Initialized
DEBUG - 2014-01-11 20:42:31 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:42:31 --> Model Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Config Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:43:28 --> URI Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Router Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Output Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Security Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Input Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:43:28 --> Language Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Loader Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:43:28 --> Controller Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:43:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:43:28 --> Model Class Initialized
DEBUG - 2014-01-11 20:43:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:43:28 --> Model Class Initialized
ERROR - 2014-01-11 20:43:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 490
ERROR - 2014-01-11 20:43:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 502
ERROR - 2014-01-11 20:43:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 503
ERROR - 2014-01-11 20:43:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 511
DEBUG - 2014-01-11 20:43:44 --> Config Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:43:44 --> URI Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Router Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Output Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Security Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Input Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:43:44 --> Language Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Loader Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:43:44 --> Controller Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:43:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:43:44 --> Model Class Initialized
DEBUG - 2014-01-11 20:43:44 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:43:44 --> Model Class Initialized
ERROR - 2014-01-11 20:43:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 490
ERROR - 2014-01-11 20:43:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 502
ERROR - 2014-01-11 20:43:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 503
ERROR - 2014-01-11 20:43:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/master/Projects/www/kreantis/listslider/server/application/helpers/dump_helper.php:26) /home/master/Projects/www/kreantis/listslider/server/application/libraries/REST_Controller.php 511
DEBUG - 2014-01-11 20:44:05 --> Config Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:44:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:44:05 --> URI Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Router Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Output Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Security Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Input Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:44:05 --> Language Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Loader Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:44:05 --> Controller Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:44:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:44:05 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:05 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:44:05 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Config Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:44:09 --> URI Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Router Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Output Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Security Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Input Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:44:09 --> Language Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Loader Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:44:09 --> Controller Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:44:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:44:09 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:09 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:44:09 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Config Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:44:16 --> URI Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Router Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Output Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Security Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Input Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:44:16 --> Language Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Loader Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:44:16 --> Controller Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:44:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:44:16 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:44:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:44:16 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Config Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:44:21 --> URI Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Router Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Output Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Security Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Input Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:44:21 --> Language Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Loader Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:44:21 --> Controller Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:44:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:44:21 --> Model Class Initialized
DEBUG - 2014-01-11 20:44:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:44:21 --> Model Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Config Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:47:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:47:51 --> URI Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Router Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Output Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Security Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Input Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:47:51 --> Language Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Loader Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:47:51 --> Controller Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:47:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:47:51 --> Model Class Initialized
DEBUG - 2014-01-11 20:47:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:47:51 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Config Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:48:06 --> URI Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Router Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Output Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Security Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Input Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:48:06 --> Language Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Loader Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:48:06 --> Controller Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:48:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:48:06 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:48:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:48:06 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Config Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:48:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:48:27 --> URI Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Router Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Output Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Security Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Input Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:48:27 --> Language Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Loader Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:48:27 --> Controller Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:48:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:48:27 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:27 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:48:27 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Config Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 20:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 20:48:28 --> URI Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Router Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Output Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Security Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Input Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 20:48:28 --> Language Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Loader Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 20:48:28 --> Controller Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 20:48:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 20:48:28 --> Model Class Initialized
DEBUG - 2014-01-11 20:48:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 20:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 20:48:28 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Config Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:02:06 --> URI Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Router Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Output Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Security Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Input Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:02:06 --> Language Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Loader Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:02:06 --> Controller Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:02:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:02:06 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:02:06 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Config Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:02:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:02:23 --> URI Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Router Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Output Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Security Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Input Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:02:23 --> Language Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Loader Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:02:23 --> Controller Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:02:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:02:23 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:23 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:02:23 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Config Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:02:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:02:33 --> URI Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Router Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Output Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Security Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Input Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:02:33 --> Language Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Loader Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:02:33 --> Controller Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:02:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:02:33 --> Model Class Initialized
DEBUG - 2014-01-11 21:02:33 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:02:33 --> Model Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Config Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:04:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:04:30 --> URI Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Router Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Output Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Security Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Input Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:04:30 --> Language Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Loader Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:04:30 --> Controller Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:04:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:04:30 --> Model Class Initialized
DEBUG - 2014-01-11 21:04:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:04:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:04:30 --> Model Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Config Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:05:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:05:19 --> URI Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Router Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Output Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Security Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Input Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:05:19 --> Language Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Loader Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:05:19 --> Controller Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:05:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:05:19 --> Model Class Initialized
DEBUG - 2014-01-11 21:05:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:05:19 --> Model Class Initialized
ERROR - 2014-01-11 21:05:19 --> Severity: Notice  --> Undefined index: ANY todo/list /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 38
DEBUG - 2014-01-11 21:06:34 --> Config Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:06:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:06:34 --> URI Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Router Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Output Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Security Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Input Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:06:34 --> Language Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Loader Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:06:34 --> Controller Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:06:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:06:34 --> Model Class Initialized
DEBUG - 2014-01-11 21:06:34 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:06:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:06:34 --> Model Class Initialized
ERROR - 2014-01-11 21:06:34 --> Severity: Notice  --> Undefined variable: apiName /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 44
DEBUG - 2014-01-11 21:06:44 --> Config Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:06:44 --> URI Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Router Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Output Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Security Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Input Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:06:44 --> Language Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Loader Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:06:44 --> Controller Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:06:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:06:44 --> Model Class Initialized
DEBUG - 2014-01-11 21:06:44 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:06:44 --> Model Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Config Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:06:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:06:48 --> URI Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Router Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Output Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Security Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Input Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:06:48 --> Language Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Loader Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:06:48 --> Controller Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:06:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:06:48 --> Model Class Initialized
DEBUG - 2014-01-11 21:06:48 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:06:48 --> Model Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Config Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:07:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:07:19 --> URI Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Router Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Output Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Security Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Input Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:07:19 --> Language Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Loader Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:07:19 --> Controller Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:07:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-01-11 21:07:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:07:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Config Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:09:43 --> URI Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Router Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Output Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Security Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Input Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:09:43 --> Language Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Loader Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:09:43 --> Controller Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:09:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:09:43 --> Model Class Initialized
DEBUG - 2014-01-11 21:09:43 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:09:43 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Config Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:16:31 --> URI Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Router Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Output Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Security Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Input Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:16:31 --> Language Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Loader Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:16:31 --> Controller Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:16:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:16:31 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:31 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:16:31 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Config Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:16:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:16:36 --> URI Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Router Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Output Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Security Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Input Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:16:36 --> Language Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Loader Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:16:36 --> Controller Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:16:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:16:36 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:16:36 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Config Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:16:44 --> URI Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Router Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Output Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Security Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Input Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:16:44 --> Language Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Loader Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:16:44 --> Controller Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:16:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:16:44 --> Model Class Initialized
DEBUG - 2014-01-11 21:16:44 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:16:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:16:44 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Config Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:17:04 --> URI Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Router Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Output Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Security Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Input Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:17:04 --> Language Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Loader Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:17:04 --> Controller Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:17:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:17:04 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:04 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:17:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:17:04 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Config Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:17:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:17:13 --> URI Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Router Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Output Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Security Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Input Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:17:13 --> Language Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Loader Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:17:13 --> Controller Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:17:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:17:13 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:17:13 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Config Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:17:47 --> URI Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Router Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Output Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Security Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Input Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:17:47 --> Language Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Loader Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:17:47 --> Controller Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:17:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:17:47 --> Model Class Initialized
DEBUG - 2014-01-11 21:17:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:17:47 --> Model Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Config Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:18:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:18:06 --> URI Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Router Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Output Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Security Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Input Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:18:06 --> Language Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Loader Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:18:06 --> Controller Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:18:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:18:06 --> Model Class Initialized
DEBUG - 2014-01-11 21:18:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:18:06 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Config Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:43:11 --> URI Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Router Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Output Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Security Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Input Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:43:11 --> Language Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Loader Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:43:11 --> Controller Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:43:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:43:11 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:11 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:43:11 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Config Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:43:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:43:35 --> URI Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Router Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Output Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Security Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Input Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:43:35 --> Language Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Loader Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:43:35 --> Controller Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:43:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:43:35 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:35 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:43:35 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Config Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:43:45 --> URI Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Router Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Output Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Security Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Input Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:43:45 --> Language Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Loader Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:43:45 --> Controller Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:43:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:43:45 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:43:45 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Config Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:43:52 --> URI Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Router Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Output Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Security Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Input Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:43:52 --> Language Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Loader Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:43:52 --> Controller Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:43:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:43:52 --> Model Class Initialized
DEBUG - 2014-01-11 21:43:52 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:43:52 --> Model Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Config Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:47:10 --> URI Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Router Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Output Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Security Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Input Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:47:10 --> Language Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Loader Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:47:10 --> Controller Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:47:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:47:10 --> Model Class Initialized
DEBUG - 2014-01-11 21:47:10 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:47:10 --> Model Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Config Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:47:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:47:47 --> URI Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Router Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Output Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Security Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Input Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:47:47 --> Language Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Loader Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:47:47 --> Controller Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:47:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:47:47 --> Model Class Initialized
DEBUG - 2014-01-11 21:47:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:47:47 --> Model Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Config Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:48:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:48:16 --> URI Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Router Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Output Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Security Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Input Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:48:16 --> Language Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Loader Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:48:16 --> Controller Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:48:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:48:16 --> Model Class Initialized
DEBUG - 2014-01-11 21:48:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:48:16 --> Model Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Config Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:50:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:50:46 --> URI Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Router Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Output Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Security Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Input Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:50:46 --> Language Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Loader Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:50:46 --> Controller Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:50:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:50:46 --> Model Class Initialized
DEBUG - 2014-01-11 21:50:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:50:46 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Config Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:51:01 --> URI Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Router Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Output Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Security Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Input Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:51:01 --> Language Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Loader Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:51:01 --> Controller Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:51:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:51:01 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:51:01 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Config Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:51:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:51:08 --> URI Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Router Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Output Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Security Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Input Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:51:08 --> Language Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Loader Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:51:08 --> Controller Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:51:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:51:08 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:51:08 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Config Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:51:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:51:43 --> URI Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Router Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Output Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Security Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Input Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:51:43 --> Language Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Loader Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:51:43 --> Controller Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:51:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:51:43 --> Model Class Initialized
DEBUG - 2014-01-11 21:51:43 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:51:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:51:43 --> Model Class Initialized
ERROR - 2014-01-11 21:51:43 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 77
ERROR - 2014-01-11 21:51:43 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 77
ERROR - 2014-01-11 21:51:43 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 77
ERROR - 2014-01-11 21:51:43 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 77
DEBUG - 2014-01-11 21:52:02 --> Config Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:52:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:52:02 --> URI Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Router Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Output Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Security Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Input Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:52:02 --> Language Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Loader Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:52:02 --> Controller Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:52:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:52:02 --> Model Class Initialized
DEBUG - 2014-01-11 21:52:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:52:02 --> Model Class Initialized
ERROR - 2014-01-11 21:52:02 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
ERROR - 2014-01-11 21:52:02 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
ERROR - 2014-01-11 21:52:02 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
ERROR - 2014-01-11 21:52:02 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
DEBUG - 2014-01-11 21:52:10 --> Config Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:52:10 --> URI Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Router Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Output Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Security Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Input Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:52:10 --> Language Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Loader Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:52:10 --> Controller Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:52:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:52:10 --> Model Class Initialized
DEBUG - 2014-01-11 21:52:10 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:52:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:52:10 --> Model Class Initialized
ERROR - 2014-01-11 21:52:10 --> Severity: Warning  --> Invalid error type specified /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
DEBUG - 2014-01-11 21:52:55 --> Config Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:52:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:52:55 --> URI Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Router Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Output Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Security Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Input Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:52:55 --> Language Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Loader Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:52:55 --> Controller Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:52:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:52:55 --> Model Class Initialized
DEBUG - 2014-01-11 21:52:55 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:52:55 --> Model Class Initialized
ERROR - 2014-01-11 21:52:55 --> Severity: User Warning  --> Api: "GET todo/list" Invalid type of param ["id:number"] /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 78
DEBUG - 2014-01-11 21:53:42 --> Config Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:53:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:53:42 --> URI Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Router Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Output Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Security Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Input Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:53:42 --> Language Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Loader Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:53:42 --> Controller Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:53:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:53:42 --> Model Class Initialized
DEBUG - 2014-01-11 21:53:42 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:53:42 --> Model Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Config Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 21:54:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 21:54:01 --> URI Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Router Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Output Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Security Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Input Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 21:54:01 --> Language Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Loader Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 21:54:01 --> Controller Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 21:54:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 21:54:01 --> Model Class Initialized
DEBUG - 2014-01-11 21:54:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 21:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 21:54:01 --> Model Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Config Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:00:33 --> URI Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Router Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Output Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Security Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Input Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:00:33 --> Language Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Loader Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:00:33 --> Controller Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:00:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:00:33 --> Model Class Initialized
DEBUG - 2014-01-11 22:00:33 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:00:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:00:33 --> Model Class Initialized
ERROR - 2014-01-11 22:00:33 --> Severity: Warning  --> preg_split() expects parameter 2 to be string, array given /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 89
ERROR - 2014-01-11 22:00:33 --> Severity: Notice  --> Undefined offset: 0 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 95
ERROR - 2014-01-11 22:00:33 --> Severity: Notice  --> Undefined offset: 0 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 103
DEBUG - 2014-01-11 22:01:21 --> Config Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:01:21 --> URI Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Router Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Output Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Security Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Input Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:01:21 --> Language Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Loader Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:01:21 --> Controller Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:01:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:01:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:01:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:01:21 --> Model Class Initialized
ERROR - 2014-01-11 22:01:21 --> Severity: Warning  --> preg_split() expects parameter 2 to be string, array given /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 89
ERROR - 2014-01-11 22:01:21 --> Severity: Notice  --> Undefined offset: 0 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 95
ERROR - 2014-01-11 22:01:21 --> Severity: Notice  --> Undefined offset: 0 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 103
DEBUG - 2014-01-11 22:01:43 --> Config Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:01:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:01:43 --> URI Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Router Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Output Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Security Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Input Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:01:43 --> Language Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Loader Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:01:43 --> Controller Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:01:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:01:43 --> Model Class Initialized
DEBUG - 2014-01-11 22:01:43 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:01:43 --> Model Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Config Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:02:53 --> URI Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Router Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Output Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Security Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Input Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:02:53 --> Language Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Loader Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:02:53 --> Controller Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:02:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:02:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:02:53 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:02:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:02:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Config Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:03:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:03:48 --> URI Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Router Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Output Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Security Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Input Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:03:48 --> Language Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Loader Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:03:48 --> Controller Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:03:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:03:48 --> Model Class Initialized
DEBUG - 2014-01-11 22:03:48 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:03:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:03:48 --> Model Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Config Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:03:59 --> URI Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Router Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Output Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Security Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Input Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:03:59 --> Language Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Loader Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:03:59 --> Controller Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:03:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 22:03:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Config Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:04:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:04:25 --> URI Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Router Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Output Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Security Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Input Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:04:25 --> Language Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Loader Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:04:25 --> Controller Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:04:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:04:25 --> Model Class Initialized
DEBUG - 2014-01-11 22:04:25 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:04:25 --> Model Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Config Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:04:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:04:58 --> URI Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Router Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Output Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Security Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Input Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:04:58 --> Language Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Loader Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:04:58 --> Controller Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:04:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:04:58 --> Model Class Initialized
DEBUG - 2014-01-11 22:04:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:04:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:04:58 --> Model Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Config Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:05:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:05:17 --> URI Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Router Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Output Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Security Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Input Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:05:17 --> Language Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Loader Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:05:17 --> Controller Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:05:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:05:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:05:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:05:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:05:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Config Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:06:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:06:06 --> URI Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Router Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Output Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Security Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Input Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:06:06 --> Language Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Loader Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:06:06 --> Controller Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:06:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:06:06 --> Model Class Initialized
DEBUG - 2014-01-11 22:06:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:06:06 --> Model Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Config Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:06:59 --> URI Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Router Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Output Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Security Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Input Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:06:59 --> Language Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Loader Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:06:59 --> Controller Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:06:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:06:59 --> Model Class Initialized
DEBUG - 2014-01-11 22:06:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:06:59 --> Model Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Config Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:11:23 --> URI Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Router Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Output Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Security Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Input Class Initialized
DEBUG - 2014-01-11 22:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:11:23 --> Language Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Config Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:11:55 --> URI Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Router Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Output Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Security Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Input Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:11:55 --> Language Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Loader Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:11:55 --> Controller Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:11:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:11:55 --> Model Class Initialized
DEBUG - 2014-01-11 22:11:55 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:11:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:11:55 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Config Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:14:37 --> URI Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Router Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Output Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Security Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Input Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:14:37 --> Language Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Loader Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:14:37 --> Controller Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:14:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:14:37 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:37 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:14:37 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Config Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:14:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:14:45 --> URI Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Router Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Output Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Security Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Input Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:14:45 --> Language Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Loader Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:14:45 --> Controller Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:14:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:14:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:14:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:14:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Config Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:14:57 --> URI Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Router Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Output Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Security Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Input Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:14:57 --> Language Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Loader Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:14:57 --> Controller Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:14:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:14:57 --> Model Class Initialized
DEBUG - 2014-01-11 22:14:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:14:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:14:57 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Config Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:15:03 --> URI Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Router Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Output Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Security Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Input Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:15:03 --> Language Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Loader Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:15:03 --> Controller Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:15:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:15:03 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:15:03 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Config Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:15:07 --> URI Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Router Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Output Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Security Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Input Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:15:07 --> Language Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Loader Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:15:07 --> Controller Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:15:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:15:07 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:07 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:15:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:15:07 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Config Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:15:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:15:10 --> URI Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Router Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Output Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Security Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Input Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:15:10 --> Language Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Loader Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:15:10 --> Controller Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:15:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:15:10 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:10 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:15:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:15:10 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Config Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:15:16 --> URI Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Router Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Output Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Security Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Input Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:15:16 --> Language Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Loader Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:15:16 --> Controller Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:15:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:15:16 --> Model Class Initialized
DEBUG - 2014-01-11 22:15:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:15:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:15:16 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:20:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:20:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:20:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:20:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:20:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:20:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Config Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:20:32 --> URI Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Router Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Output Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Security Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Input Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:20:32 --> Language Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Loader Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:20:32 --> Controller Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:20:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:20:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:20:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:20:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Config Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:20:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:20:53 --> URI Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Router Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Output Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Security Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Input Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:20:53 --> Language Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Loader Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:20:53 --> Controller Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:20:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:20:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:20:53 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:20:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Config Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:21:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:21:33 --> URI Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Router Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Output Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Security Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Input Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:21:33 --> Language Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Loader Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:21:33 --> Controller Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:21:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:21:33 --> Model Class Initialized
DEBUG - 2014-01-11 22:21:33 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:21:33 --> Model Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Config Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:21:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:21:50 --> URI Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Router Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Output Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Security Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Input Class Initialized
DEBUG - 2014-01-11 22:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:21:50 --> Language Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Config Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:21:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:21:54 --> URI Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Router Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Output Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Security Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Input Class Initialized
DEBUG - 2014-01-11 22:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:21:54 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Config Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:22:02 --> URI Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Router Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Output Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Security Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Input Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:22:02 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Loader Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:22:02 --> Controller Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:22:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:22:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:22:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:22:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:22:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:22:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:22:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:22:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:22:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:22:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:22:13 --> Model Class Initialized
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
ERROR - 2014-01-11 22:22:13 --> Severity: Notice  --> Undefined offset: 1 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 56
DEBUG - 2014-01-11 22:22:22 --> Config Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:22:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:22:22 --> URI Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Router Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Output Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Security Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Input Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:22:22 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Loader Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:22:22 --> Controller Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:22:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:22:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:22:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Config Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:22:30 --> URI Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Router Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Output Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Security Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Input Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:22:30 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Loader Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:22:30 --> Controller Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:22:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:22:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:22:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:22:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Config Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:22:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:22:36 --> URI Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Router Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Output Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Security Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Input Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:22:36 --> Language Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Loader Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:22:36 --> Controller Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:22:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:22:36 --> Model Class Initialized
DEBUG - 2014-01-11 22:22:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:22:36 --> Model Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Config Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:23:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:23:22 --> URI Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Router Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Output Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Security Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Input Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:23:22 --> Language Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Loader Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:23:22 --> Controller Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:23:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:23:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:23:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:23:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Config Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:23:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:23:46 --> URI Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Router Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Output Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Security Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Input Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:23:46 --> Language Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Loader Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:23:46 --> Controller Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:23:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:23:46 --> Model Class Initialized
DEBUG - 2014-01-11 22:23:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:23:46 --> Model Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Config Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:24:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:24:07 --> URI Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Router Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Output Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Security Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Input Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:24:07 --> Language Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Loader Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:24:07 --> Controller Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:24:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:24:07 --> Model Class Initialized
DEBUG - 2014-01-11 22:24:07 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:24:07 --> Model Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Config Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:24:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:24:51 --> URI Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Router Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Output Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Security Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Input Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:24:51 --> Language Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Loader Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:24:51 --> Controller Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:24:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:24:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:24:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:24:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Config Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:25:32 --> URI Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Router Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Output Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Security Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Input Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:25:32 --> Language Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Loader Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:25:32 --> Controller Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:25:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:25:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:25:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:25:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Config Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:27:38 --> URI Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Router Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Output Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Security Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Input Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:27:38 --> Language Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Loader Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:27:38 --> Controller Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:27:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:27:38 --> Model Class Initialized
DEBUG - 2014-01-11 22:27:38 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:27:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:27:38 --> Model Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Config Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:29:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:29:42 --> URI Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Router Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Output Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Security Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Input Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:29:42 --> Language Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Loader Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:29:42 --> Controller Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:29:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:29:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:29:42 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:29:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Config Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:30:33 --> URI Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Router Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Output Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Security Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Input Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:30:33 --> Language Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Loader Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:30:33 --> Controller Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:30:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-11 22:30:33 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:30:33 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Config Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:31:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:31:26 --> URI Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Router Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Output Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Security Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Input Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:31:26 --> Language Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Loader Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:31:26 --> Controller Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:31:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:31:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:26 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:31:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Config Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:31:49 --> URI Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Router Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Output Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Security Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Input Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:31:49 --> Language Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Loader Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:31:49 --> Controller Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:31:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:31:49 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:49 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:31:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:31:49 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Config Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:31:50 --> URI Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Router Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Output Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Security Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Input Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:31:50 --> Language Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Loader Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:31:50 --> Controller Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:31:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:31:50 --> Model Class Initialized
DEBUG - 2014-01-11 22:31:50 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:31:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:31:50 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Config Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:32:19 --> URI Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Router Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Output Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Security Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Input Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:32:19 --> Language Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Loader Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:32:19 --> Controller Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:32:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:32:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:32:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:32:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Config Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:32:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:32:31 --> URI Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Router Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Output Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Security Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Input Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:32:31 --> Language Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Loader Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:32:31 --> Controller Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:32:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:32:31 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:31 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:32:31 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Config Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:32:52 --> URI Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Router Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Output Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Security Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Input Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:32:52 --> Language Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Loader Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:32:52 --> Controller Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:32:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:32:52 --> Model Class Initialized
DEBUG - 2014-01-11 22:32:52 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:32:52 --> Model Class Initialized
ERROR - 2014-01-11 22:32:52 --> Severity: Warning  --> preg_match(): Delimiter must not be alphanumeric or backslash /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 71
DEBUG - 2014-01-11 22:33:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:33:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:33:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:33:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:33:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:33:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:33:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:33:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:33:14 --> Model Class Initialized
ERROR - 2014-01-11 22:33:14 --> Severity: Warning  --> preg_match(): Unknown modifier 't' /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 72
DEBUG - 2014-01-11 22:33:57 --> Config Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:33:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:33:57 --> URI Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Router Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Output Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Security Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Input Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:33:57 --> Language Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Loader Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:33:57 --> Controller Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:33:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:33:57 --> Model Class Initialized
DEBUG - 2014-01-11 22:33:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:33:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:33:57 --> Model Class Initialized
ERROR - 2014-01-11 22:33:57 --> Severity: Warning  --> preg_replace(): Unknown modifier ']' /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 68
DEBUG - 2014-01-11 22:34:08 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:08 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:08 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:08 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:08 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:08 --> Model Class Initialized
ERROR - 2014-01-11 22:34:08 --> Severity: Warning  --> preg_replace(): Compilation failed: missing terminating ] for character class at offset 13 /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 68
DEBUG - 2014-01-11 22:34:17 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:17 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:17 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:17 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:44 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:44 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:44 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:44 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:51 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:51 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:51 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:53 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:53 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:53 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:53 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:53 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:53 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:53 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:53 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Config Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:34:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:34:54 --> URI Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Router Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Output Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Security Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Input Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:34:54 --> Language Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Loader Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:34:54 --> Controller Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:34:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:34:54 --> Model Class Initialized
DEBUG - 2014-01-11 22:34:54 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:34:54 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:03 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:03 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:03 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:03 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:03 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:15 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:15 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:15 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:15 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:15 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:15 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:16 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:16 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:16 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:16 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:16 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:17 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:17 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:17 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:17 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:17 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:17 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:17 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:17 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:17 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:17 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:35 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:35 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:35 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:35 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:35 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:35 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:46 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:46 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:46 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:46 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:46 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:47 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:47 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:47 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:47 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:47 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Config Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:35:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:35:51 --> URI Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Router Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Output Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Security Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Input Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:35:51 --> Language Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Loader Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:35:51 --> Controller Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:35:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:35:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:35:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:35:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Config Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:36:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:36:08 --> URI Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Router Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Output Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Security Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Input Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:36:08 --> Language Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Loader Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:36:08 --> Controller Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:36:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:36:08 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:08 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:36:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:36:08 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Config Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:36:51 --> URI Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Router Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Output Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Security Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Input Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:36:51 --> Language Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Loader Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:36:51 --> Controller Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:36:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:36:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:36:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:36:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Config Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:36:51 --> URI Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Router Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Output Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Security Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Input Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:36:51 --> Language Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Loader Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:36:51 --> Controller Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:36:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:36:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:36:51 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:36:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:36:51 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Config Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:37:00 --> URI Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Router Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Output Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Security Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Input Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:37:00 --> Language Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Loader Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:37:00 --> Controller Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:37:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:37:00 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:37:00 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Config Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:37:18 --> URI Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Router Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Output Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Security Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Input Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:37:18 --> Language Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Loader Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:37:18 --> Controller Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:37:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:37:18 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:18 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:37:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:37:18 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Config Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:37:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:37:30 --> URI Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Router Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Output Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Security Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Input Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:37:30 --> Language Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Loader Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:37:30 --> Controller Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:37:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:37:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:37:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Config Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:37:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:37:44 --> URI Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Router Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Output Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Security Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Input Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:37:44 --> Language Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Loader Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:37:44 --> Controller Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:37:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:37:44 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:44 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:37:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:37:44 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Config Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:37:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:37:52 --> URI Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Router Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Output Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Security Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Input Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:37:52 --> Language Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Loader Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:37:52 --> Controller Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:37:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:37:52 --> Model Class Initialized
DEBUG - 2014-01-11 22:37:52 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:37:52 --> Model Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Config Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:38:02 --> URI Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Router Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Output Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Security Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Input Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:38:02 --> Language Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Loader Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:38:02 --> Controller Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:38:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:38:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:38:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:38:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Config Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:38:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:38:20 --> URI Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Router Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Output Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Security Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Input Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:38:20 --> Language Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Loader Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:38:20 --> Controller Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:38:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:38:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:38:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:38:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Config Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:40:06 --> URI Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Router Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Output Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Security Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Input Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:40:06 --> Language Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Loader Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:40:06 --> Controller Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:40:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:40:06 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:06 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:40:06 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:40:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:40:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:40:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:40:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:40:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:40:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Config Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:40:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:40:52 --> URI Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Router Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Output Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Security Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Input Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:40:52 --> Language Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Loader Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:40:52 --> Controller Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:40:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:40:52 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:52 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:40:52 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Config Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:40:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:40:57 --> URI Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Router Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Output Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Security Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Input Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:40:57 --> Language Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Loader Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:40:57 --> Controller Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:40:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:40:57 --> Model Class Initialized
DEBUG - 2014-01-11 22:40:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:40:57 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Config Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:41:09 --> URI Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Router Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Output Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Security Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Input Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:41:09 --> Language Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Loader Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:41:09 --> Controller Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:41:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:41:09 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:09 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:41:09 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Config Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:41:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:41:28 --> URI Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Router Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Output Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Security Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Input Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:41:28 --> Language Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Loader Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:41:28 --> Controller Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:41:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:41:28 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:41:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:41:28 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Config Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:41:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:41:44 --> URI Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Router Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Output Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Security Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Input Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:41:44 --> Language Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Loader Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:41:44 --> Controller Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:41:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:41:44 --> Model Class Initialized
DEBUG - 2014-01-11 22:41:44 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:41:44 --> Model Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Config Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:42:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:42:24 --> URI Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Router Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Output Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Security Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Input Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:42:24 --> Language Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Loader Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:42:24 --> Controller Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:42:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:42:24 --> Model Class Initialized
DEBUG - 2014-01-11 22:42:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:42:24 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Config Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:43:21 --> URI Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Router Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Output Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Security Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Input Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:43:21 --> Language Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Loader Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:43:21 --> Controller Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:43:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:43:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:43:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Config Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:43:26 --> URI Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Router Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Output Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Security Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Input Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:43:26 --> Language Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Loader Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:43:26 --> Controller Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:43:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:26 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:43:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Config Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:43:32 --> URI Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Router Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Output Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Security Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Input Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:43:32 --> Language Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Loader Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:43:32 --> Controller Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:43:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:43:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:43:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:43:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Config Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:43:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:43:37 --> URI Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Router Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Output Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Security Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Input Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:43:37 --> Language Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Loader Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:43:37 --> Controller Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:43:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:43:37 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:37 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:43:37 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:41 --> Config Class Initialized
DEBUG - 2014-01-11 22:43:41 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:43:41 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:43:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:43:41 --> URI Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Router Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Output Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Security Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Input Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:43:42 --> Language Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Loader Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:43:42 --> Controller Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:43:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:43:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:43:42 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:43:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Config Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:44:26 --> URI Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Router Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Output Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Security Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Input Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:44:26 --> Language Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Loader Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:44:26 --> Controller Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:44:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:44:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:44:26 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:44:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:44:26 --> Model Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Config Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:44:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:44:30 --> URI Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Router Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Output Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Security Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Input Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:44:30 --> Language Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Loader Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:44:30 --> Controller Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:44:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:44:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:44:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:44:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:44:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Config Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:45:31 --> URI Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Router Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Output Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Security Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Input Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:45:31 --> Language Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Loader Class Initialized
DEBUG - 2014-01-11 22:45:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:45:31 --> Controller Class Initialized
DEBUG - 2014-01-11 22:45:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:45:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:45:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:45:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:45:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:45:32 --> Model Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:47:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:47:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:47:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:47:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:47:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:47:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:47:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:52:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:52:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:52:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:52:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:52:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:52:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:52:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:52:13 --> Model Class Initialized
ERROR - 2014-01-11 22:52:13 --> Severity: Notice  --> Array to string conversion /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 149
ERROR - 2014-01-11 22:52:13 --> Severity: Notice  --> Array to string conversion /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 149
DEBUG - 2014-01-11 22:52:24 --> Config Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:52:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:52:24 --> URI Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Router Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Output Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Security Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Input Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:52:24 --> Language Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Loader Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:52:24 --> Controller Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:52:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:52:24 --> Model Class Initialized
DEBUG - 2014-01-11 22:52:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:52:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:52:24 --> Model Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Config Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:52:50 --> URI Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Router Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Output Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Security Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Input Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:52:50 --> Language Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Loader Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:52:50 --> Controller Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:52:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:52:50 --> Model Class Initialized
DEBUG - 2014-01-11 22:52:50 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:52:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:52:50 --> Model Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Config Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:53:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:53:02 --> URI Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Router Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Output Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Security Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Input Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:53:02 --> Language Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Loader Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:53:02 --> Controller Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:53:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:53:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:53:02 --> Model Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Config Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:53:34 --> URI Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Router Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Output Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Security Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Input Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:53:34 --> Language Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Loader Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:53:34 --> Controller Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:53:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:53:34 --> Model Class Initialized
DEBUG - 2014-01-11 22:53:34 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:53:34 --> Model Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Config Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:54:45 --> URI Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Router Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Output Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Security Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Input Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:54:45 --> Language Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Loader Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:54:45 --> Controller Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:54:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:54:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:54:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:12 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:12 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:12 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:12 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:12 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:12 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:45 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:45 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:45 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:45 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Config Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:55:56 --> URI Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Router Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Output Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Security Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Input Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:55:56 --> Language Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Loader Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:55:56 --> Controller Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:55:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:55:56 --> Model Class Initialized
DEBUG - 2014-01-11 22:55:56 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:55:56 --> Model Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Config Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:56:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:56:04 --> URI Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Router Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Output Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Security Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Input Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:56:04 --> Language Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Loader Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:56:04 --> Controller Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:56:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:56:04 --> Model Class Initialized
DEBUG - 2014-01-11 22:56:04 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:56:04 --> Model Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Config Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:57:11 --> URI Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Router Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Output Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Security Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Input Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:57:11 --> Language Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Loader Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:57:11 --> Controller Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:57:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:57:11 --> Model Class Initialized
DEBUG - 2014-01-11 22:57:11 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:57:11 --> Model Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Config Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:57:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:57:30 --> URI Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Router Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Output Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Security Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Input Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:57:30 --> Language Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Loader Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:57:30 --> Controller Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:57:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:57:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:57:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:57:30 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Config Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:58:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:58:28 --> URI Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Router Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Output Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Security Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Input Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:58:28 --> Language Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Loader Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:58:28 --> Controller Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:58:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:58:28 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:58:28 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Config Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:58:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:58:38 --> URI Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Router Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Output Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Security Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Input Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:58:38 --> Language Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Loader Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:58:38 --> Controller Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:58:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:58:38 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:38 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:58:38 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Config Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:58:41 --> URI Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Router Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Output Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Security Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Input Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:58:41 --> Language Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Loader Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:58:41 --> Controller Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:58:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:58:41 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:58:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:58:41 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Config Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:58:41 --> URI Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Router Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Output Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Security Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Input Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:58:41 --> Language Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Loader Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:58:41 --> Controller Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:58:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:58:41 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:41 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:58:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:58:41 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Config Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:58:42 --> URI Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Router Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Output Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Security Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Input Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:58:42 --> Language Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Loader Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:58:42 --> Controller Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:58:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:58:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:58:42 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:58:42 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:11 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:11 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:11 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:11 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:11 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:11 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:13 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:13 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:13 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:13 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:13 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:14 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:14 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:14 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:14 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:14 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:18 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:18 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:18 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:18 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:18 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:18 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:19 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:19 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:19 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:19 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:19 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:19 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:19 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:20 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:20 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:20 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:20 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:20 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:20 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:20 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:21 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:21 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:21 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:21 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:21 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:21 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:21 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:22 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:22 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:22 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:22 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Config Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Hooks Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Utf8 Class Initialized
DEBUG - 2014-01-11 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 22:59:27 --> URI Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Router Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Output Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Security Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Input Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 22:59:27 --> Language Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Loader Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 22:59:27 --> Controller Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 22:59:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 22:59:27 --> Model Class Initialized
DEBUG - 2014-01-11 22:59:27 --> Database Driver Class Initialized
ERROR - 2014-01-11 22:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 22:59:27 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:24 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:24 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:24 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:24 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:32 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:32 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:32 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:32 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:32 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:32 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:32 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:33 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:33 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:33 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:33 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:56 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:56 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:56 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:56 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:59 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:59 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:59 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Config Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:03:59 --> URI Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Router Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Output Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Security Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Input Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:03:59 --> Language Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Loader Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:03:59 --> Controller Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:03:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:03:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:03:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Config Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:05:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:05:05 --> URI Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Router Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Output Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Security Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Input Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:05:05 --> Language Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Loader Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:05:05 --> Controller Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:05:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:05:05 --> Model Class Initialized
DEBUG - 2014-01-11 23:05:05 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:05:05 --> Model Class Initialized
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
ERROR - 2014-01-11 23:05:05 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 209
DEBUG - 2014-01-11 23:05:20 --> Config Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:05:20 --> URI Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Router Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Output Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Security Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Input Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:05:20 --> Language Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Loader Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:05:20 --> Controller Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:05:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:05:20 --> Model Class Initialized
DEBUG - 2014-01-11 23:05:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:05:20 --> Model Class Initialized
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:20 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
DEBUG - 2014-01-11 23:05:57 --> Config Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:05:57 --> URI Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Router Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Output Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Security Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Input Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:05:57 --> Language Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Loader Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:05:57 --> Controller Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:05:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:05:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:05:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:05:57 --> Model Class Initialized
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
ERROR - 2014-01-11 23:05:57 --> Severity: Notice  --> Undefined index: name /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 207
DEBUG - 2014-01-11 23:06:16 --> Config Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:06:16 --> URI Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Router Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Output Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Security Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Input Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:06:16 --> Language Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Loader Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:06:16 --> Controller Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:06:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:06:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:06:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Config Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:06:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:06:21 --> URI Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Router Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Output Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Security Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Input Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:06:21 --> Language Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Loader Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:06:21 --> Controller Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:06:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:06:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:06:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:06:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Config Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:06:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:06:22 --> URI Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Router Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Output Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Security Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Input Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:06:22 --> Language Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Loader Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:06:22 --> Controller Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:06:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:06:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:06:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Config Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:06:36 --> URI Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Router Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Output Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Security Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Input Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:06:36 --> Language Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Loader Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:06:36 --> Controller Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:06:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:06:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:06:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:06:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Config Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:07:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:07:53 --> URI Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Router Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Output Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Security Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Input Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:07:53 --> Language Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Loader Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:07:53 --> Controller Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:07:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:07:53 --> Model Class Initialized
DEBUG - 2014-01-11 23:07:53 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:07:53 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:45 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:45 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:45 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:45 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:45 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:45 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:46 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:46 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:46 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:46 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:46 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:46 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:47 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:47 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:47 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:47 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:47 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:47 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:47 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:47 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:47 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:47 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:47 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Config Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:08:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:08:48 --> URI Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Router Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Output Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Security Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Input Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:08:48 --> Language Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Loader Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:08:48 --> Controller Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:08:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:08:48 --> Model Class Initialized
DEBUG - 2014-01-11 23:08:48 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:08:48 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:34 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:34 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:34 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:34 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:34 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:34 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:34 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:35 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:35 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:35 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:35 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:35 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:35 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:35 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:35 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:35 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:35 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:35 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:36 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:36 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:36 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:36 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:36 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:36 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:37 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:37 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:37 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:37 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:37 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:37 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:37 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:37 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:37 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:37 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:37 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:38 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:38 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:38 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:38 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:38 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:38 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:55 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:55 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:55 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:55 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:55 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:55 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:55 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:55 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:55 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:55 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:55 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:56 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:56 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:56 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:56 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:56 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:56 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:56 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:57 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:57 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:57 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:57 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:57 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:57 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:58 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:58 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:58 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:58 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:58 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:58 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:58 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:58 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:58 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:59 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:59 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:59 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Config Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:10:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:10:59 --> URI Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Router Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Output Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Security Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Input Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:10:59 --> Language Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Loader Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:10:59 --> Controller Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:10:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:10:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:10:59 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:10:59 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:00 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:00 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:00 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:00 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:00 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:00 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:00 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:00 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:00 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:01 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:01 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:01 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:01 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:01 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:01 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:01 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:01 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:01 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:02 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:02 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:02 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:02 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:02 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:02 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:02 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:02 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:02 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Config Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:11:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:11:27 --> URI Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Router Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Output Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Security Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Input Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:11:27 --> Language Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Loader Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:11:27 --> Controller Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:11:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:11:27 --> Model Class Initialized
DEBUG - 2014-01-11 23:11:27 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:11:27 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:01 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:01 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:01 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:01 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:01 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:02 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:02 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:02 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:03 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:03 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:03 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:03 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:03 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:03 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:03 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:03 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:04 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:04 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:04 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:04 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:04 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:04 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:18 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:18 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:18 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:18 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:18 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:18 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:19 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:19 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:19 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:19 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:19 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:19 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:19 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:19 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:19 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:19 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:19 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Config Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:12:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:12:20 --> URI Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Router Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Output Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Security Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Input Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:12:20 --> Language Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Loader Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:12:20 --> Controller Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:12:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:12:20 --> Model Class Initialized
DEBUG - 2014-01-11 23:12:20 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:12:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:12:20 --> Model Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Config Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:14:58 --> URI Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Router Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Output Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Security Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Input Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:14:58 --> Language Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Loader Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:14:58 --> Controller Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:14:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:14:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:14:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:14:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:14:58 --> Model Class Initialized
ERROR - 2014-01-11 23:14:58 --> Severity: Warning  --> Missing argument 2 for API_Controller::_getApiNameByCurrentRequest(), called in /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php on line 32 and defined /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 191
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: arguments /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 200
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: apiName /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 34
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined variable: apiName /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 39
ERROR - 2014-01-11 23:14:58 --> Severity: Notice  --> Undefined index:  /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 39
DEBUG - 2014-01-11 23:15:12 --> Config Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:15:12 --> URI Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Router Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Output Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Security Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Input Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:15:12 --> Language Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Loader Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:15:12 --> Controller Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:15:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:15:12 --> Model Class Initialized
DEBUG - 2014-01-11 23:15:12 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:15:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:15:12 --> Model Class Initialized
ERROR - 2014-01-11 23:15:12 --> Severity: Notice  --> Undefined variable: apiName /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 34
ERROR - 2014-01-11 23:15:12 --> Severity: Notice  --> Undefined variable: apiName /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 39
ERROR - 2014-01-11 23:15:12 --> Severity: Notice  --> Undefined index:  /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 39
DEBUG - 2014-01-11 23:15:23 --> Config Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:15:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:15:23 --> URI Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Router Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Output Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Security Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Input Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:15:23 --> Language Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Loader Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:15:23 --> Controller Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:15:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:15:23 --> Model Class Initialized
DEBUG - 2014-01-11 23:15:23 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:15:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:15:23 --> Model Class Initialized
ERROR - 2014-01-11 23:15:23 --> Severity: Notice  --> Undefined index:  /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 39
DEBUG - 2014-01-11 23:15:49 --> Config Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:15:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:15:49 --> URI Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Router Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Output Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Security Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Input Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:15:49 --> Language Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Loader Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:15:49 --> Controller Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:15:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:15:49 --> Model Class Initialized
DEBUG - 2014-01-11 23:15:49 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:15:49 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:21 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:21 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:21 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:22 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:22 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:22 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:22 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:22 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:22 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:22 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:22 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:23 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:23 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:23 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:23 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:23 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:23 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:23 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:23 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:23 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:23 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:23 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:28 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:28 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:28 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:28 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:28 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:28 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:29 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:29 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:29 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:29 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:29 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:29 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:29 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:30 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:30 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:30 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:30 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:30 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:30 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:31 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:31 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:31 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:31 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:31 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:31 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:38 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:38 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:38 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:38 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:38 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:38 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Config Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:16:46 --> URI Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Router Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Output Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Security Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Input Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:16:46 --> Language Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Loader Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:16:46 --> Controller Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:16:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:16:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:16:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:16:46 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Config Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:17:56 --> URI Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Router Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Output Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Security Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Input Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:17:56 --> Language Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Loader Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:17:56 --> Controller Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:17:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:17:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:17:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:56 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Config Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:17:57 --> URI Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Router Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Output Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Security Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Input Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:17:57 --> Language Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Loader Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:17:57 --> Controller Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:17:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:17:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:17:57 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Config Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:19:17 --> URI Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Router Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Output Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Security Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Input Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:19:17 --> Language Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Loader Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:19:17 --> Controller Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:19:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:19:17 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:19:17 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:17 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Config Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:19:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:19:34 --> URI Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Router Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Output Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Security Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Input Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:19:34 --> Language Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Loader Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:19:34 --> Controller Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:19:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:19:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:19:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:19:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:19:34 --> Model Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Config Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:23:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:23:48 --> URI Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Router Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Output Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Security Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Input Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:23:48 --> Language Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Loader Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:23:48 --> Controller Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:23:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:23:48 --> Model Class Initialized
DEBUG - 2014-01-11 23:23:48 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:23:48 --> Model Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Config Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:25:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:25:02 --> URI Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Router Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Output Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Security Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Input Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:25:02 --> Language Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Loader Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:25:02 --> Controller Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:25:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:25:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:25:02 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:25:02 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Config Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:26:16 --> URI Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Router Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Output Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Security Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Input Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:26:16 --> Language Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Loader Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:26:16 --> Controller Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:26:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:26:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:26:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Config Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:26:18 --> URI Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Router Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Output Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Security Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Input Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:26:18 --> Language Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Loader Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:26:18 --> Controller Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:26:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:26:18 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:18 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:26:18 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Config Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:26:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:26:27 --> URI Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Router Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Output Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Security Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Input Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:26:27 --> Language Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Loader Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:26:27 --> Controller Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:26:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:26:27 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:27 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:26:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:26:27 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Config Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:26:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:26:36 --> URI Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Router Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Output Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Security Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Input Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:26:36 --> Language Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Loader Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:26:36 --> Controller Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:26:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:26:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:26:36 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:26:36 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Config Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:27:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:27:00 --> URI Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Router Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Output Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Security Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Input Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:27:00 --> Language Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Loader Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:27:00 --> Controller Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:27:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:27:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:00 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:27:00 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Config Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:27:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:27:29 --> URI Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Router Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Output Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Security Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Input Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:27:29 --> Language Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Loader Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:27:29 --> Controller Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:27:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:27:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:29 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:27:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:27:29 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Config Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:27:30 --> URI Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Router Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Output Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Security Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Input Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:27:30 --> Language Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Loader Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:27:30 --> Controller Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:27:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:27:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:27:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Config Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:27:30 --> URI Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Router Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Output Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Security Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Input Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:27:30 --> Language Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Loader Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:27:30 --> Controller Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:27:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:27:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:27:30 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:27:30 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Config Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:29:21 --> URI Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Router Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Output Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Security Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Input Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:29:21 --> Language Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Loader Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:29:21 --> Controller Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:29:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:29:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:21 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:29:21 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Config Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:29:28 --> URI Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Router Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Output Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Security Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Input Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:29:28 --> Language Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Loader Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:29:28 --> Controller Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:29:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:29:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:28 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:29:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:29:28 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Config Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:29:50 --> URI Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Router Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Output Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Security Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Input Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:29:50 --> Language Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Loader Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:29:50 --> Controller Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:29:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:29:50 --> Model Class Initialized
DEBUG - 2014-01-11 23:29:50 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:29:50 --> Model Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Config Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:32:32 --> URI Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Router Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Output Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Security Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Input Class Initialized
DEBUG - 2014-01-11 23:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:32:32 --> Language Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Config Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:37:06 --> URI Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Router Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Output Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Security Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Input Class Initialized
DEBUG - 2014-01-11 23:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:37:06 --> Language Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Config Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:56:58 --> URI Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Router Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Output Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Security Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Input Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:56:58 --> Language Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Loader Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:56:58 --> Controller Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:56:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:56:58 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:56:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Config Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:57:16 --> URI Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Router Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Output Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Security Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Input Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:57:16 --> Language Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Loader Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:57:16 --> Controller Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:57:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:57:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:57:16 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:57:16 --> Model Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Config Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Hooks Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Utf8 Class Initialized
DEBUG - 2014-01-11 23:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-11 23:58:41 --> URI Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Router Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Output Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Security Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Input Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-11 23:58:41 --> Language Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Loader Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-11 23:58:41 --> Controller Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-11 23:58:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-11 23:58:41 --> Model Class Initialized
DEBUG - 2014-01-11 23:58:41 --> Database Driver Class Initialized
ERROR - 2014-01-11 23:58:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-11 23:58:41 --> Model Class Initialized
