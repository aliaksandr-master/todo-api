<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-07 00:16:18 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:18 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:18 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:18 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:24 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:24 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:24 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:24 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:24 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:24 --> Model Class Initialized
ERROR - 2014-01-07 00:16:24 --> Severity: Warning  --> Missing argument 2 for Todo::item_put() /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 170
DEBUG - 2014-01-07 00:16:31 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:31 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:31 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:31 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:31 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:31 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:31 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:49 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:49 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:49 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:49 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`listslider`.`todo_item`, CONSTRAINT `todo_item_FK_1` FOREIGN KEY (`todo_id`) REFERENCES `todo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2014-01-07 00:16:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:53 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:53 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:53 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:53 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:53 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:53 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:53 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:53 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:53 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:54 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:54 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:54 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:54 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:54 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:54 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:55 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:55 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:55 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:55 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:55 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:55 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:55 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:55 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:55 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:55 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:55 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:55 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:55 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:55 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:55 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:55 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:56 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:56 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:56 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:56 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:56 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:56 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:56 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:56 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:56 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:56 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:56 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:16:59 --> Config Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:16:59 --> URI Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Router Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Output Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Security Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Input Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:16:59 --> Language Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Loader Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:16:59 --> Controller Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:16:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:16:59 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:16:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:16:59 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:59 --> Model Class Initialized
DEBUG - 2014-01-07 00:16:59 --> DB Transaction Failure
ERROR - 2014-01-07 00:16:59 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:16:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:03 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:03 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:03 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:03 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:03 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:03 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:03 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:03 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:03 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:04 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:04 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:04 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:04 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:04 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:04 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:08 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:08 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:08 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:08 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:08 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:08 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:08 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:08 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:08 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:18 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:18 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:18 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:18 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:18 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:18 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:18 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:18 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:18 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:18 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:18 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:23 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:23 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:23 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:23 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:23 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:23 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:23 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:23 --> DB Transaction Failure
ERROR - 2014-01-07 00:17:23 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 00:17:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 00:17:33 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:33 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:33 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:33 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:33 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:33 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:33 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:39 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:39 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:39 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:39 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:39 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:39 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:45 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:45 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:45 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:47 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:47 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:47 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Config Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:17:56 --> URI Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Router Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Output Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Security Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Input Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:17:56 --> Language Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Loader Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:17:56 --> Controller Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:17:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Config Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:57:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:57:45 --> URI Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Router Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Output Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Security Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Input Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:57:45 --> Language Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Loader Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:57:45 --> Controller Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:57:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:57:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:57:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:57:45 --> Model Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Config Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Hooks Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Utf8 Class Initialized
DEBUG - 2014-01-07 00:58:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 00:58:33 --> URI Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Router Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Output Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Security Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Input Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 00:58:33 --> Language Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Loader Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 00:58:33 --> Controller Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 00:58:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 00:58:33 --> Model Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Database Driver Class Initialized
ERROR - 2014-01-07 00:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 00:58:33 --> Model Class Initialized
DEBUG - 2014-01-07 00:58:33 --> Model Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Config Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:00:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:00:48 --> URI Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Router Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Output Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Security Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Input Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:00:48 --> Language Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Loader Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:00:48 --> Controller Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:00:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Config Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:01:13 --> URI Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Router Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Output Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Security Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Input Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:01:13 --> Language Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Loader Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:01:13 --> Controller Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:01:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:01:13 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:01:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:01:13 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:13 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Config Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:01:15 --> URI Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Router Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Output Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Security Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Input Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:01:15 --> Language Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Loader Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:01:15 --> Controller Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:01:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:01:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:01:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:01:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:01:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:01:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:01:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:01:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:01:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Config Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:01:18 --> URI Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Router Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Output Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Security Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Input Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:01:18 --> Language Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Loader Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:01:18 --> Controller Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:01:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:01:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:01:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Config Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:01:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:01:19 --> URI Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Router Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Output Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Security Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Input Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:01:19 --> Language Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Loader Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:01:19 --> Controller Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:01:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:01:19 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:01:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:01:19 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Model Class Initialized
DEBUG - 2014-01-07 01:01:19 --> Model Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:03:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:03:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:03:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:03:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:03:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:03:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:03:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Config Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:04:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:04:54 --> URI Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Router Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Output Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Security Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Input Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:04:54 --> Language Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Loader Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:04:54 --> Controller Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:04:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:04:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:04:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:04:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Config Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:07:52 --> URI Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Router Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Output Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Security Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Input Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:07:52 --> Language Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Loader Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:07:52 --> Controller Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:07:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Config Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:12:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:12:24 --> URI Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Router Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Output Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Security Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Input Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:12:24 --> Language Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Loader Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:12:24 --> Controller Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:12:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:12:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:12:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:12:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:00 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:00 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:00 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:01 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:01 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:01 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:01 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:01 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:01 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:01 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:03 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:03 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:03 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Config Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:15:04 --> URI Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Router Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Output Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Security Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Input Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:15:04 --> Language Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Loader Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:15:04 --> Controller Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:15:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:15:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Config Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:16:57 --> URI Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Router Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Output Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Security Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Input Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:16:57 --> Language Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Loader Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:16:57 --> Controller Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:16:57 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:16:57 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 01:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:41 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:41 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:41 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:41 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:41 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:46 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:46 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:46 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:17:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:47 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:47 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:47 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:48 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:48 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:48 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:17:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:54 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:54 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:54 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:54 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:54 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:55 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:55 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:55 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:55 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:55 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:55 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:55 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:55 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:55 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:55 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:56 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:56 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:56 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:56 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:56 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:56 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:56 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:56 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:56 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:56 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:56 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:56 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:17:56 --> URI Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Router Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Output Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Security Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Input Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:17:56 --> Language Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Loader Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:17:56 --> Controller Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:17:56 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:17:56 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:17:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:17:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Config Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:18:03 --> URI Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Router Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Output Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Security Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Input Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:18:03 --> Language Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Loader Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:18:03 --> Controller Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:18:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:18:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:18:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:18:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:18:03 --> Model Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Config Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:19:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:19:56 --> URI Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Router Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Output Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Security Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Input Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:19:56 --> Language Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Loader Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:19:56 --> Controller Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:19:56 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:19:56 --> Severity: Notice  --> Use of undefined constant PUT_VAL - assumed 'PUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:19:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:19:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:19:56 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Config Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:20:14 --> URI Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Router Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Output Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Security Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Input Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:20:14 --> Language Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Loader Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:20:14 --> Controller Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:20:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Config Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:20:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:20:55 --> URI Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Router Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Output Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Security Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Input Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:20:55 --> Language Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Loader Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:20:55 --> Controller Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:20:55 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:20:55 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
ERROR - 2014-01-07 01:20:55 --> Severity: Notice  --> Undefined variable: _PUT /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 49
DEBUG - 2014-01-07 01:20:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:20:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:20:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:20:55 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:11 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:11 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:11 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:11 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:11 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:11 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:11 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:11 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:11 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:11 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:29 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:29 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:29 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:29 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:29 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:38 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:38 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:38 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:38 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:38 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:38 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:38 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:38 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:38 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:39 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:39 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:39 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:39 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:21:39 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:39 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:39 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:44 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:44 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:44 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:44 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:44 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:45 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:45 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:45 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:45 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:45 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:46 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:46 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:46 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:46 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:46 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Config Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:21:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:21:46 --> URI Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Router Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Output Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Security Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Input Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:21:46 --> Language Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Loader Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:21:46 --> Controller Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:21:46 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:21:46 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:21:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:14 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:14 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:14 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:14 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:14 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:15 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:15 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:15 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:15 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:15 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:15 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:15 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:15 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:15 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:15 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:16 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:16 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:16 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:16 --> Helper loaded: inflector_helper
ERROR - 2014-01-07 01:22:16 --> Severity: Notice  --> Use of undefined constant INPUT_VAL - assumed 'INPUT_VAL' /home/master/Projects/www/kreantis/listslider/server/application/libraries/data_transfer/DataTransfer.php 46
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:23 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:23 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:23 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:22:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:24 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:24 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:24 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:22:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Config Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:22:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:22:37 --> URI Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Router Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Output Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Security Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Input Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:22:37 --> Language Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Loader Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:22:37 --> Controller Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:22:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:22:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:22:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:22:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:12 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:12 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:12 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:48 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:48 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:48 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:48 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:49 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:49 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:49 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:49 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:49 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:49 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:52 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:52 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:52 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:52 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:53 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:53 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:53 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:53 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:53 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:53 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:53 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:53 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:53 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:53 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:54 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:54 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:54 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:54 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:54 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:54 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:24:54 --> URI Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Router Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Output Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Security Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Input Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:24:54 --> Language Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Loader Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:24:54 --> Controller Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:24:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:24:54 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:25:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:25:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:25:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:25:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:25:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:25:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Config Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:25:46 --> URI Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Router Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Output Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Security Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Input Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:25:46 --> Language Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Loader Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:25:46 --> Controller Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:25:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:25:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:25:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:25:46 --> Model Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Config Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:26:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:26:50 --> URI Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Router Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Output Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Security Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Input Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:26:50 --> Language Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Loader Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:26:50 --> Controller Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:26:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:26:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:26:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:26:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:04 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:04 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:04 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:06 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:06 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:06 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:06 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:06 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:06 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:06 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:06 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:06 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:08 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:08 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:08 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:11 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:11 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:11 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:11 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:11 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:11 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:11 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:11 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Config Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:27:15 --> URI Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Router Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Output Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Security Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Input Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:27:15 --> Language Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Loader Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:27:15 --> Controller Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:27:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:27:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:27:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:27:15 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Config Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:30:35 --> URI Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Router Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Output Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Security Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Input Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:30:35 --> Language Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Loader Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:30:35 --> Controller Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:30:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:30:35 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:30:35 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:35 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Config Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:30:36 --> URI Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Router Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Output Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Security Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Input Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:30:36 --> Language Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Loader Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:30:36 --> Controller Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:30:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:30:36 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:30:36 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:36 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Config Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:30:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:30:41 --> URI Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Router Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Output Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Security Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Input Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:30:41 --> Language Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Loader Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:30:41 --> Controller Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:30:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:30:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:30:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:30:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:41 --> DB Transaction Failure
ERROR - 2014-01-07 01:30:41 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 01:30:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 01:30:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:30:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:30:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:30:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:30:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:30:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:30:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:30:45 --> DB Transaction Failure
ERROR - 2014-01-07 01:30:45 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 01:30:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 01:31:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:31:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:31:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:31:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:31:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:31:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:31:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:31:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:31:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:31:02 --> DB Transaction Failure
ERROR - 2014-01-07 01:31:02 --> Query error: Column 'is_shared' cannot be null
DEBUG - 2014-01-07 01:31:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-07 01:32:37 --> Config Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:32:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:32:37 --> URI Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Router Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Output Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Security Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Input Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:32:37 --> Language Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Loader Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:32:37 --> Controller Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:32:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:32:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:32:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:32:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:32:37 --> Model Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Config Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:33:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:33:50 --> URI Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Router Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Output Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Security Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Input Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:33:50 --> Language Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Loader Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:33:50 --> Controller Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:33:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:33:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:33:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:33:50 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:25 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:25 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:25 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:25 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:25 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:25 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:27 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:27 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:27 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:27 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:27 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:27 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:27 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:28 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:28 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:28 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:29 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:29 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:29 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Config Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:37:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:37:29 --> URI Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Router Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Output Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Security Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Input Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:37:29 --> Language Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Loader Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:37:29 --> Controller Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:37:29 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:37:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:37:29 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:02 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:02 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:02 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:02 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:04 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:04 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:04 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:04 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:04 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:04 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:04 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:05 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:05 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:05 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:05 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:05 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:05 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:05 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:08 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:08 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:08 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:08 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:10 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:10 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:10 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:10 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:10 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:10 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:12 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:12 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:12 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:12 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:14 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:14 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:14 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:14 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:16 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:16 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:16 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:18 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:18 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:18 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:18 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:20 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:20 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:20 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:20 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:20 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:20 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:21 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:21 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:21 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:21 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:21 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:21 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:23 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:23 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:23 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:23 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:24 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:24 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:24 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:24 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:26 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:26 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:26 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:26 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:26 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:26 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:28 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:28 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:28 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:28 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:31 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:31 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:31 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:31 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:31 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:31 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:33 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:33 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:33 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:33 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:33 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:33 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:40 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:40 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:40 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:40 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:40 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:40 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:40 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:40 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:40 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:43 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:43 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:43 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:47 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:47 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:47 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Config Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:50:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:50:47 --> URI Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Router Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Output Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Security Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Input Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:50:47 --> Language Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Loader Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:50:47 --> Controller Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:50:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:50:47 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:40 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:40 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:40 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:40 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:40 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:40 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:40 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:41 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:41 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:41 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:41 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:42 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:42 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:42 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:42 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:43 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:43 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:43 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:43 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:43 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:43 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:43 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:44 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:44 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:44 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:44 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:44 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:44 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:44 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Config Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 01:55:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 01:55:45 --> URI Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Router Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Output Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Security Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Input Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 01:55:45 --> Language Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Loader Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 01:55:45 --> Controller Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 01:55:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 01:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 01:55:45 --> Model Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Config Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:14:58 --> URI Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Router Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Output Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Security Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Input Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:14:58 --> Language Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Loader Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:14:58 --> Controller Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:14:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:14:58 --> Model Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:14:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:14:58 --> Model Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Model Class Initialized
DEBUG - 2014-01-07 02:14:58 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:04 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:04 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:04 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:10 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:10 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:10 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:10 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:10 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:10 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:17 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:17 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:17 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:17 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:17 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:17 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:20 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:20 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:20 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:20 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:20 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:20 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:20 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:20 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:20 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:20 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:47 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:47 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:47 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:47 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:47 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:47 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:47 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:51 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:51 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:51 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:51 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:51 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:51 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:55 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:55 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:55 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:55 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:55 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:55 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Config Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:15:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:15:59 --> URI Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Router Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Output Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Security Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Input Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:15:59 --> Language Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Loader Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:15:59 --> Controller Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:15:59 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:15:59 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:15:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:15:59 --> Model Class Initialized
DEBUG - 2014-01-07 02:15:59 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Config Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:16:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:16:01 --> URI Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Router Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Output Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Security Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Input Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:16:01 --> Language Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Loader Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:16:01 --> Controller Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:16:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:16:01 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:16:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:16:01 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:01 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Config Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:16:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:16:54 --> URI Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Router Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Output Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Security Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Input Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:16:54 --> Language Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Loader Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:16:54 --> Controller Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:16:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:54 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Config Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 02:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 02:16:57 --> URI Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Router Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Output Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Security Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Input Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 02:16:57 --> Language Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Loader Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 02:16:57 --> Controller Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 02:16:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 02:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 02:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 02:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 02:16:57 --> Model Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Config Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:47:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:47:48 --> URI Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Router Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Output Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Security Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Input Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:47:48 --> Language Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Loader Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:47:48 --> Controller Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:47:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:47:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:47:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:47:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Config Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:49:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:49:28 --> URI Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Router Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Output Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Security Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Input Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:49:28 --> Language Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Loader Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:49:28 --> Controller Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:49:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Config Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:49:48 --> URI Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Router Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Output Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Security Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Input Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:49:48 --> Language Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Loader Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:49:48 --> Controller Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:49:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:49:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:49:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:49:48 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Config Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:50:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:50:13 --> URI Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Router Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Output Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Security Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Input Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:50:13 --> Language Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Loader Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:50:13 --> Controller Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:50:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:50:13 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:50:13 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:13 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Config Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:50:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:50:16 --> URI Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Router Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Output Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Security Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Input Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:50:16 --> Language Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Loader Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:50:16 --> Controller Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:50:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 17:50:16 --> Model Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Config Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:51:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:51:40 --> URI Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Router Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Output Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Security Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Input Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:51:40 --> Language Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Loader Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:51:40 --> Controller Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:51:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:51:40 --> Model Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:51:40 --> Model Class Initialized
DEBUG - 2014-01-07 17:51:40 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Config Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:52:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:52:21 --> URI Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Router Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Output Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Security Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Input Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:52:21 --> Language Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Loader Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:52:21 --> Controller Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:52:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:52:21 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:52:21 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:21 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Config Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:52:56 --> URI Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Router Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Output Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Security Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Input Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:52:56 --> Language Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Loader Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:52:56 --> Controller Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:52:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:52:56 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:52:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:52:56 --> Model Class Initialized
DEBUG - 2014-01-07 17:52:56 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Config Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:54:09 --> URI Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Router Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Output Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Security Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Input Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:54:09 --> Language Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Loader Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:54:09 --> Controller Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:54:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:54:09 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:54:09 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:09 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Config Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:54:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:54:18 --> URI Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Router Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Output Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Security Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Input Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:54:18 --> Language Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Loader Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:54:18 --> Controller Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:54:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:54:18 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:54:18 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:18 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Config Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:54:31 --> URI Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Router Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Output Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Security Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Input Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:54:31 --> Language Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Loader Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:54:31 --> Controller Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:54:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:54:31 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:54:31 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:31 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Config Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:54:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:54:36 --> URI Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Router Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Output Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Security Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Input Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:54:36 --> Language Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Loader Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:54:36 --> Controller Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:54:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:54:36 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:54:36 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:36 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Config Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:54:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:54:41 --> URI Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Router Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Output Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Security Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Input Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:54:41 --> Language Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Loader Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:54:41 --> Controller Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:54:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:54:41 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:54:41 --> Model Class Initialized
DEBUG - 2014-01-07 17:54:41 --> Model Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Config Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:56:38 --> URI Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Router Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Output Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Security Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Input Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:56:38 --> Language Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Loader Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:56:38 --> Controller Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:56:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:56:38 --> Model Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:56:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:56:38 --> Model Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Model Class Initialized
DEBUG - 2014-01-07 17:56:38 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Config Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:57:19 --> URI Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Router Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Output Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Security Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Input Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:57:19 --> Language Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Loader Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:57:19 --> Controller Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:57:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:57:19 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:57:19 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:19 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Config Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:57:25 --> URI Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Router Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Output Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Security Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Input Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:57:25 --> Language Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Loader Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:57:25 --> Controller Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:57:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:57:25 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:57:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:57:25 --> Model Class Initialized
DEBUG - 2014-01-07 17:57:25 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Config Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:59:27 --> URI Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Router Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Output Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Security Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Input Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:59:27 --> Language Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Loader Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:59:27 --> Controller Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:59:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:59:27 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:59:27 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:27 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Config Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:59:30 --> URI Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Router Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Output Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Security Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Input Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:59:30 --> Language Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Loader Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:59:30 --> Controller Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:59:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Config Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:59:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:59:37 --> URI Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Router Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Output Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Security Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Input Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:59:37 --> Language Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Loader Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:59:37 --> Controller Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:59:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:59:37 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:37 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:59:37 --> Model Class Initialized
ERROR - 2014-01-07 17:59:37 --> Severity: Warning  --> Missing argument 1 for Todo::list_put() /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 75
DEBUG - 2014-01-07 17:59:37 --> Model Class Initialized
ERROR - 2014-01-07 17:59:37 --> Severity: Notice  --> Undefined variable: listId /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 87
ERROR - 2014-01-07 17:59:37 --> Severity: Notice  --> Undefined variable: listId /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 89
DEBUG - 2014-01-07 17:59:37 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Config Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 17:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 17:59:44 --> URI Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Router Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Output Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Security Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Input Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 17:59:44 --> Language Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Loader Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 17:59:44 --> Controller Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 17:59:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 17:59:44 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 17:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 17:59:44 --> Model Class Initialized
DEBUG - 2014-01-07 17:59:44 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Config Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:00:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:00:16 --> URI Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Router Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Output Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Security Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Input Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:00:16 --> Language Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Loader Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:00:16 --> Controller Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:00:16 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:00:16 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:00:16 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:16 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Config Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:00:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:00:46 --> URI Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Router Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Output Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Security Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Input Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:00:46 --> Language Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Loader Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:00:46 --> Controller Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:00:46 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:00:46 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:00:46 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:46 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Config Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:00:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:00:48 --> URI Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Router Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Output Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Security Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Input Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:00:48 --> Language Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Loader Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:00:48 --> Controller Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:00:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:00:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Config Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:01:27 --> URI Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Router Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Output Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Security Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Input Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:01:27 --> Language Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Loader Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:01:27 --> Controller Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:01:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:01:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:01:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Config Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:01:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:01:30 --> URI Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Router Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Output Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Security Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Input Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:01:30 --> Language Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Loader Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:01:30 --> Controller Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:01:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:01:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:01:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:01:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Config Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:21:14 --> URI Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Router Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Output Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Security Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Input Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:21:14 --> Language Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Loader Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:21:14 --> Controller Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:21:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:21:14 --> Model Class Initialized
DEBUG - 2014-01-07 18:21:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:21:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:21:14 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:33:14 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:15 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:15 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:15 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:15 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:15 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:15 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:19 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:19 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:19 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:22 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:22 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:22 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:26 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:26 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:26 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:26 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:26 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:26 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:27 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:27 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:27 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:28 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:28 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:28 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:28 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:28 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:28 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:28 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:28 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:34 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:34 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:34 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:34 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:34 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:34 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:34 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:34 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:34 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:35 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:35 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:35 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:35 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:35 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:35 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:35 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:44 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:44 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:44 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:44 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:44 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:44 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:44 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Config Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:33:45 --> URI Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Router Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Output Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Security Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Input Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:33:45 --> Language Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Loader Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:33:45 --> Controller Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:33:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:33:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:33:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:33:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Config Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:35:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:35:25 --> URI Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Router Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Output Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Security Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Input Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:35:25 --> Language Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Loader Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:35:25 --> Controller Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:35:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:35:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:35:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:35:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Config Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:35:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:35:27 --> URI Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Router Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Output Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Security Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Input Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:35:27 --> Language Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Loader Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:35:27 --> Controller Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:35:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:35:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:35:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:35:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Config Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:35:32 --> URI Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Router Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Output Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Security Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Input Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:35:32 --> Language Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Loader Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:35:32 --> Controller Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:35:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:35:32 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:35:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:35:32 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:32 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Config Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:35:45 --> URI Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Router Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Output Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Security Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Input Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:35:45 --> Language Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Loader Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:35:45 --> Controller Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:35:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:35:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:35:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:45 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Config Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:35:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:35:54 --> URI Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Router Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Output Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Security Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Input Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:35:54 --> Language Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Loader Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:35:54 --> Controller Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:35:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:35:54 --> Model Class Initialized
DEBUG - 2014-01-07 18:35:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:35:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:35:54 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:37:22 --> Config Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:37:22 --> URI Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Router Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Output Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Security Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Input Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:37:22 --> Language Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Loader Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:37:22 --> Controller Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:37:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:37:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:37:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:37:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:22 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Config Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:37:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:37:33 --> URI Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Router Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Output Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Security Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Input Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:37:33 --> Language Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Loader Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:37:33 --> Controller Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:37:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:37:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:37:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:37:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Config Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:37:41 --> URI Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Router Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Output Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Security Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Input Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:37:41 --> Language Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Loader Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:37:41 --> Controller Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:37:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:37:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:37:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:37:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:37:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Config Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:38:47 --> URI Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Router Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Output Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Security Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Input Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:38:47 --> Language Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Loader Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:38:47 --> Controller Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:38:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:38:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:38:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:38:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:38:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Config Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:39:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:39:23 --> URI Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Router Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Output Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Security Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Input Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:39:23 --> Language Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Loader Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:39:23 --> Controller Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:39:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:39:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:39:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Config Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:39:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:39:53 --> URI Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Router Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Output Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Security Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Input Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:39:53 --> Language Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Loader Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:39:53 --> Controller Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:39:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:39:53 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:39:53 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Model Class Initialized
DEBUG - 2014-01-07 18:39:53 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Config Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:40:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:40:19 --> URI Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Router Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Output Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Security Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Input Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:40:19 --> Language Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Loader Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:40:19 --> Controller Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:40:19 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:40:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:40:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:40:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:19 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Config Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:40:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:40:30 --> URI Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Router Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Output Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Security Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Input Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:40:30 --> Language Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Loader Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:40:30 --> Controller Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:40:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:40:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:40:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:40:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Config Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:40:34 --> URI Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Router Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Output Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Security Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Input Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:40:34 --> Language Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Loader Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:40:34 --> Controller Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:40:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:40:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:40:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:34 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Config Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:40:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:40:40 --> URI Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Router Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Output Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Security Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Input Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:40:40 --> Language Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Loader Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:40:40 --> Controller Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:40:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:40:40 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:40:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:40:40 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:40 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Config Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:40:50 --> URI Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Router Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Output Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Security Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Input Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:40:50 --> Language Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Loader Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:40:50 --> Controller Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:40:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:40:50 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:40:50 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Model Class Initialized
DEBUG - 2014-01-07 18:40:50 --> Model Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Config Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:41:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:41:48 --> URI Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Router Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Output Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Security Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Input Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:41:48 --> Language Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Loader Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:41:48 --> Controller Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:41:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:41:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:41:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:41:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:41:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Config Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:42:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:42:06 --> URI Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Router Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Output Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Security Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Input Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:42:06 --> Language Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Loader Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:42:06 --> Controller Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:42:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:42:06 --> Model Class Initialized
DEBUG - 2014-01-07 18:42:06 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:42:06 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:43:00 --> Config Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:43:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:43:00 --> URI Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Router Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Output Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Security Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Input Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:43:00 --> Language Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Loader Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:43:00 --> Controller Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:43:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:43:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:43:00 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:43:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:43:00 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:44:27 --> Config Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:44:27 --> URI Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Router Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Output Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Security Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Input Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:44:27 --> Language Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Loader Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:44:27 --> Controller Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:44:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:44:27 --> Model Class Initialized
DEBUG - 2014-01-07 18:44:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:44:27 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:44:58 --> Config Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:44:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:44:58 --> URI Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Router Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Output Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Security Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Input Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:44:58 --> Language Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Loader Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:44:58 --> Controller Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:44:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:44:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:44:58 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:44:58 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:45:48 --> Config Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:45:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:45:48 --> URI Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Router Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Output Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Security Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Input Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:45:48 --> Language Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Loader Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:45:48 --> Controller Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:45:48 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:45:48 --> Model Class Initialized
DEBUG - 2014-01-07 18:45:48 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:45:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:45:48 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:46:30 --> Config Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:46:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:46:30 --> URI Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Router Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Output Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Security Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Input Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:46:30 --> Language Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Loader Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:46:30 --> Controller Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:46:30 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:46:30 --> Model Class Initialized
DEBUG - 2014-01-07 18:46:30 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:46:30 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:46:52 --> Config Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:46:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:46:52 --> URI Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Router Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Output Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Security Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Input Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:46:52 --> Language Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Loader Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:46:52 --> Controller Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:46:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:46:52 --> Model Class Initialized
DEBUG - 2014-01-07 18:46:52 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:46:52 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:47:49 --> Config Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:47:49 --> URI Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Router Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Output Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Security Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Input Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:47:49 --> Language Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Loader Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:47:49 --> Controller Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:47:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:47:49 --> Model Class Initialized
DEBUG - 2014-01-07 18:47:49 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:47:49 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:48:25 --> Config Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:48:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:48:25 --> URI Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Router Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Output Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Security Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Input Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:48:25 --> Language Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Loader Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:48:25 --> Controller Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:48:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:48:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 18:48:25 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 18:48:33 --> Config Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:48:33 --> URI Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Router Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Output Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Security Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Input Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:48:33 --> Language Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Loader Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:48:33 --> Controller Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:48:33 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:33 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Config Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:48:36 --> URI Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Router Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Output Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Security Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Input Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:48:36 --> Language Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Loader Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:48:36 --> Controller Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:48:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:48:36 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:48:36 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:36 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Config Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:48:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:48:38 --> URI Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Router Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Output Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Security Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Input Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:48:38 --> Language Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Loader Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:48:38 --> Controller Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:48:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:48:38 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:48:38 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Model Class Initialized
DEBUG - 2014-01-07 18:48:38 --> Model Class Initialized
DEBUG - 2014-01-07 18:49:16 --> Config Class Initialized
DEBUG - 2014-01-07 18:49:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:49:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:49:16 --> URI Class Initialized
DEBUG - 2014-01-07 18:49:16 --> Router Class Initialized
DEBUG - 2014-01-07 18:49:16 --> Output Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Security Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Input Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:49:17 --> Language Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Loader Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:49:17 --> Controller Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:49:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:49:17 --> Model Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:49:17 --> Model Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Model Class Initialized
DEBUG - 2014-01-07 18:49:17 --> Model Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Config Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:50:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:50:01 --> URI Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Router Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Output Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Security Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Input Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:50:01 --> Language Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Loader Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:50:01 --> Controller Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:50:01 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:50:01 --> Model Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:50:01 --> Model Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Model Class Initialized
DEBUG - 2014-01-07 18:50:01 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Config Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:51:02 --> URI Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Router Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Output Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Security Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Input Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:51:02 --> Language Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Loader Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:51:02 --> Controller Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:51:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Config Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:51:02 --> URI Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Router Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Output Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Security Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Input Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:51:02 --> Language Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Loader Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:51:02 --> Controller Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:51:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:02 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Config Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:51:07 --> URI Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Router Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Output Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Security Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Input Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:51:07 --> Language Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Loader Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:51:07 --> Controller Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:51:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:51:07 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:51:07 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Model Class Initialized
DEBUG - 2014-01-07 18:51:07 --> Model Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Config Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:52:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:52:00 --> URI Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Router Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Output Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Security Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Input Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:52:00 --> Language Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Loader Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:52:00 --> Controller Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:52:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:52:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:52:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:52:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Config Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:53:57 --> URI Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Router Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Output Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Security Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Input Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:53:57 --> Language Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Loader Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:53:57 --> Controller Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:53:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:53:57 --> Model Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:53:57 --> Model Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Model Class Initialized
DEBUG - 2014-01-07 18:53:57 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Config Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:56:25 --> URI Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Router Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Output Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Security Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Input Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:56:25 --> Language Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Loader Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:56:25 --> Controller Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:56:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:56:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:56:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:25 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Config Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:56:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:56:43 --> URI Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Router Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Output Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Security Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Input Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:56:43 --> Language Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Loader Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:56:43 --> Controller Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:56:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:56:43 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:56:43 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Model Class Initialized
DEBUG - 2014-01-07 18:56:43 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Config Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:57:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:57:00 --> URI Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Router Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Output Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Security Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Input Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:57:00 --> Language Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Loader Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:57:00 --> Controller Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:57:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:57:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:57:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:00 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Config Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:57:23 --> URI Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Router Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Output Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Security Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Input Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:57:23 --> Language Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Loader Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:57:23 --> Controller Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:57:23 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:57:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:57:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:57:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:23 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Config Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:57:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:57:41 --> URI Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Router Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Output Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Security Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Input Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:57:41 --> Language Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Loader Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:57:41 --> Controller Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:57:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:57:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:57:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:57:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:41 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Config Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:57:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:57:47 --> URI Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Router Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Output Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Security Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Input Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:57:47 --> Language Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Loader Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:57:47 --> Controller Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:57:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:57:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:57:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:47 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Config Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:57:58 --> URI Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Router Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Output Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Security Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Input Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:57:58 --> Language Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Loader Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:57:58 --> Controller Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:57:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:57:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:57:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:57:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Config Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:58:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:58:05 --> URI Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Router Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Output Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Security Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Input Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:58:05 --> Language Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Loader Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:58:05 --> Controller Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:58:05 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:58:05 --> Model Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:58:05 --> Model Class Initialized
DEBUG - 2014-01-07 18:58:05 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Config Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:59:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:59:03 --> URI Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Router Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Output Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Security Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Input Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:59:03 --> Language Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Loader Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:59:03 --> Controller Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:59:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:59:03 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:59:03 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:03 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Config Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 18:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 18:59:58 --> URI Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Router Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Output Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Security Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Input Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 18:59:58 --> Language Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Loader Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 18:59:58 --> Controller Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 18:59:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Database Driver Class Initialized
ERROR - 2014-01-07 18:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-01-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Config Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:00:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:00:06 --> URI Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Router Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Output Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Security Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Input Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:00:06 --> Language Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Loader Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:00:06 --> Controller Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:00:06 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:00:06 --> Model Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:00:06 --> Model Class Initialized
DEBUG - 2014-01-07 19:00:06 --> Model Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Config Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:00:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:00:15 --> URI Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Router Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Output Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Security Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Input Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:00:15 --> Language Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Loader Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:00:15 --> Controller Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:00:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:00:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:00:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:00:15 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:01:14 --> Config Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:01:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:01:14 --> URI Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Router Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Output Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Security Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Input Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:01:14 --> Language Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Loader Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:01:14 --> Controller Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:01:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:01:14 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:01:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:01:14 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:01:32 --> Config Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:01:32 --> URI Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Router Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Output Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Security Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Input Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:01:32 --> Language Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Loader Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:01:32 --> Controller Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:01:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:01:32 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:32 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:01:32 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:01:47 --> Config Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:01:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:01:47 --> URI Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Router Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Output Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Security Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Input Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:01:47 --> Language Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Loader Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:01:47 --> Controller Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:01:47 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:01:47 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:47 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:01:47 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:01:51 --> Config Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:01:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:01:51 --> URI Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Router Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Output Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Security Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Input Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:01:51 --> Language Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Loader Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:01:51 --> Controller Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:01:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:01:51 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:01:51 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Model Class Initialized
DEBUG - 2014-01-07 19:01:51 --> Model Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Config Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:02:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:02:27 --> URI Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Router Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Output Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Security Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Input Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:02:27 --> Language Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Loader Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:02:27 --> Controller Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:02:27 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:02:27 --> Model Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:02:27 --> Model Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Model Class Initialized
DEBUG - 2014-01-07 19:02:27 --> Model Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Config Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:14:32 --> URI Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Router Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Output Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Security Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Input Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:14:32 --> Language Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Loader Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:14:32 --> Controller Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:14:32 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:14:32 --> Model Class Initialized
DEBUG - 2014-01-07 19:14:32 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:14:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:14:32 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:14:37 --> Config Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:14:37 --> URI Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Router Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Output Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Security Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Input Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:14:37 --> Language Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Loader Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:14:37 --> Controller Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:14:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:14:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:14:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:14:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Config Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:17:04 --> URI Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Router Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Output Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Security Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Input Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:17:04 --> Language Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Loader Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:17:04 --> Controller Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:17:04 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:17:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:04 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Config Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:17:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:17:58 --> URI Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Router Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Output Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Security Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Input Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:17:58 --> Language Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Loader Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:17:58 --> Controller Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:17:58 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:17:58 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:17:58 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Model Class Initialized
DEBUG - 2014-01-07 19:17:58 --> Model Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Config Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:20:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:20:22 --> URI Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Router Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Output Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Security Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Input Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:20:22 --> Language Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Loader Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:20:22 --> Controller Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:20:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:20:22 --> Model Class Initialized
DEBUG - 2014-01-07 19:20:22 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:20:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-01-07 19:20:22 --> Unable to load the requested class: data_transfer
DEBUG - 2014-01-07 19:22:08 --> Config Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:22:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:22:08 --> URI Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Router Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Output Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Security Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Input Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:22:08 --> Language Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Loader Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:22:08 --> Controller Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:22:08 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:22:08 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:22:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:22:08 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:08 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Config Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:22:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:22:15 --> URI Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Router Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Output Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Security Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Input Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:22:15 --> Language Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Loader Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:22:15 --> Controller Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:22:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Config Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:22:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:22:57 --> URI Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Router Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Output Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Security Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Input Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:22:57 --> Language Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Loader Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:22:57 --> Controller Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:22:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Config Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:28:41 --> URI Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Router Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Output Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Security Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Input Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:28:41 --> Language Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Loader Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:28:41 --> Controller Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:28:41 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:28:41 --> Model Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:28:41 --> Model Class Initialized
DEBUG - 2014-01-07 19:28:41 --> Model Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Config Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:29:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:29:15 --> URI Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Router Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Output Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Security Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Input Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:29:15 --> Language Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Loader Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:29:15 --> Controller Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:29:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:29:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:29:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:29:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:29:15 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Config Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:30:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:30:21 --> URI Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Router Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Output Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Security Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Input Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:30:21 --> Language Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Loader Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:30:21 --> Controller Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:30:21 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:30:21 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:30:21 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:21 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Config Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:30:22 --> URI Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Router Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Output Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Security Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Input Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:30:22 --> Language Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Loader Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:30:22 --> Controller Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:30:22 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:30:22 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:30:22 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:22 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Config Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:30:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:30:42 --> URI Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Router Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Output Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Security Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Input Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:30:42 --> Language Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Loader Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:30:42 --> Controller Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:30:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-01-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Config Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:31:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:31:14 --> URI Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Router Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Output Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Security Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Input Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:31:14 --> Language Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Loader Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:31:14 --> Controller Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:31:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:31:14 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:31:14 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:14 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Config Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:31:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:31:57 --> URI Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Router Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Output Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Security Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Input Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:31:57 --> Language Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Loader Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:31:57 --> Controller Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:31:57 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:31:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:31:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:31:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:31:57 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Config Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:32:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:32:20 --> URI Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Router Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Output Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Security Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Input Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:32:20 --> Language Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Loader Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:32:20 --> Controller Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:32:20 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:32:20 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:32:20 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:20 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Config Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:32:25 --> URI Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Router Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Output Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Security Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Input Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:32:25 --> Language Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Loader Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:32:25 --> Controller Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:32:25 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:32:25 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:32:25 --> Model Class Initialized
DEBUG - 2014-01-07 19:32:25 --> Model Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Config Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:35:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:35:49 --> URI Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Router Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Output Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Security Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Input Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:35:49 --> Language Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Loader Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:35:49 --> Controller Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:35:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:35:49 --> Model Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:35:49 --> Model Class Initialized
DEBUG - 2014-01-07 19:35:49 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:03 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:03 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:03 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:03 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:03 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:03 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:07 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:07 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:07 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:07 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:07 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:07 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:07 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:10 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:10 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:10 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:10 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:10 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:10 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:13 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:13 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:13 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:13 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:13 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:13 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:13 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:40 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:40 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:40 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:40 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:40 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:40 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Config Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:37:55 --> URI Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Router Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Output Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Security Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Input Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:37:55 --> Language Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Loader Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:37:55 --> Controller Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:37:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:37:55 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:37:55 --> Model Class Initialized
DEBUG - 2014-01-07 19:37:55 --> Model Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Config Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:38:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:38:53 --> URI Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Router Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Output Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Security Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Input Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:38:53 --> Language Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Loader Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:38:53 --> Controller Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:38:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:38:53 --> Model Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:38:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:38:53 --> Model Class Initialized
DEBUG - 2014-01-07 19:38:53 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Config Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:40:31 --> URI Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Router Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Output Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Security Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Input Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:40:31 --> Language Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Loader Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:40:31 --> Controller Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:40:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:40:31 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:40:31 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:31 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Config Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:40:45 --> URI Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Router Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Output Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Security Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Input Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:40:45 --> Language Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Loader Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:40:45 --> Controller Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:40:45 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:40:45 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:40:45 --> Model Class Initialized
DEBUG - 2014-01-07 19:40:45 --> Model Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Config Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 19:45:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 19:45:37 --> URI Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Router Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Output Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Security Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Input Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 19:45:37 --> Language Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Loader Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 19:45:37 --> Controller Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 19:45:37 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 19:45:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Database Driver Class Initialized
ERROR - 2014-01-07 19:45:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 19:45:37 --> Model Class Initialized
DEBUG - 2014-01-07 19:45:37 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:34 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:34 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:34 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:34 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:34 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:34 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:34 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:42 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:42 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:42 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:42 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:42 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:42 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:54 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:54 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:54 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:54 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:54 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:54 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:55 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:55 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:55 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:55 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:55 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:55 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:55 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:55 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:55 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:55 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:55 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:55 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:55 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:56 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:56 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:56 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Config Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:13:56 --> URI Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Router Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Output Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Security Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Input Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:13:56 --> Language Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Loader Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:13:56 --> Controller Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:13:56 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:13:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:13:56 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:00 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:00 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:00 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:00 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:00 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:14 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:14 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:14 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:14 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:14 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:14 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:14 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:17 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:17 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:17 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:17 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:17 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:17 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:17 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:17 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:17 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:17 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:18 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:18 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:18 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Config Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:15:18 --> URI Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Router Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Output Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Security Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Input Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:15:18 --> Language Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Loader Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:15:18 --> Controller Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:15:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:15:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Config Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:20:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:20:43 --> URI Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Router Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Output Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Security Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Input Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:20:43 --> Language Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Loader Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:20:43 --> Controller Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:20:43 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:20:43 --> Model Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:20:43 --> Model Class Initialized
DEBUG - 2014-01-07 20:20:43 --> Model Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Config Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:25:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:25:51 --> URI Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Router Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Output Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Security Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Input Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:25:51 --> Language Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Loader Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:25:51 --> Controller Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:25:51 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:25:51 --> Model Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:25:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:25:51 --> Model Class Initialized
DEBUG - 2014-01-07 20:25:51 --> Model Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Config Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:26:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:26:09 --> URI Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Router Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Output Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Security Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Input Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:26:09 --> Language Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Loader Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:26:09 --> Controller Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:26:09 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:26:09 --> Model Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:26:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:26:09 --> Model Class Initialized
DEBUG - 2014-01-07 20:26:09 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Config Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:27:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:27:18 --> URI Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Router Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Output Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Security Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Input Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:27:18 --> Language Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Loader Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:27:18 --> Controller Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:27:18 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:27:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:27:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:27:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:18 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Config Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Hooks Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Utf8 Class Initialized
DEBUG - 2014-01-07 20:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 20:27:53 --> URI Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Router Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Output Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Security Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Input Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 20:27:53 --> Language Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Loader Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-07 20:27:53 --> Controller Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-07 20:27:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-07 20:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Database Driver Class Initialized
ERROR - 2014-01-07 20:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-07 20:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 20:27:53 --> Model Class Initialized
