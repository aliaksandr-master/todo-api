<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-06 00:45:27 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:27 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:27 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:27 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:28 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:28 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:28 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:28 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:28 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:28 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:28 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:29 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:29 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:29 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:29 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:29 --> Controller Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Config Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:45:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:45:30 --> URI Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Router Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Output Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Security Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Input Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:45:30 --> Language Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Loader Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:45:30 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:48 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:48 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:48 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:48 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:48 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:49 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:49 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:49 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:49 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:49 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:49 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:49 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:49 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:49 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:50 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:50 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:50 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:50 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:50 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:50 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:50 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:50 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:50 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:51 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:51 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Controller Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Config Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:46:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:46:51 --> URI Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Router Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Output Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Security Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Input Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:46:51 --> Language Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Loader Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:46:51 --> Controller Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Config Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:47:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:47:24 --> URI Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Router Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Output Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Security Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Input Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:47:24 --> Language Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Loader Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:47:24 --> Controller Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Config Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:47:26 --> URI Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Router Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Output Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Security Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Input Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:47:26 --> Language Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Loader Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Controller Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Config Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:47:26 --> URI Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Router Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Output Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Security Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Input Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:47:26 --> Language Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Loader Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:47:26 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:04 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:04 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:04 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:08 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:08 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:08 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:09 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:09 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:09 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:09 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:09 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:10 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:10 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:10 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:42 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:42 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:42 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:42 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:42 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:43 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:43 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:43 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:43 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Controller Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Config Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:49:43 --> URI Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Router Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Output Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Security Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Input Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:49:43 --> Language Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Loader Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:49:43 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:03 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:03 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:03 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:04 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:04 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:04 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:05 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:05 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:05 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:05 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:05 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:06 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:06 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:06 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:06 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:06 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:06 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:06 --> Controller Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:29 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:29 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:29 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:29 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:39 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:39 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:40 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:40 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:40 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:40 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:40 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:40 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:40 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:40 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:40 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:40 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:41 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:41 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:41 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:41 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:41 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:41 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:41 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:41 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Config Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:50:41 --> URI Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Router Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Output Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Security Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Input Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:50:41 --> Language Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Loader Class Initialized
DEBUG - 2013-12-06 00:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Config Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:51:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:51:52 --> URI Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Router Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Output Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Security Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Input Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:51:52 --> Language Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Loader Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:51:52 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Config Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:51:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:51:52 --> URI Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Router Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Output Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Security Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Input Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:51:52 --> Language Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Loader Class Initialized
DEBUG - 2013-12-06 00:51:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:51:52 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Config Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:51:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:51:53 --> URI Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Router Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Output Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Security Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Input Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:51:53 --> Language Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Loader Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:51:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Config Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:51:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:51:53 --> URI Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Router Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Output Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Security Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Input Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:51:53 --> Language Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Loader Class Initialized
DEBUG - 2013-12-06 00:51:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:51:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Config Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:52:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:52:51 --> URI Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Router Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Output Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Security Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Input Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:52:51 --> Language Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Loader Class Initialized
DEBUG - 2013-12-06 00:52:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:52:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Config Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:52:52 --> URI Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Router Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Output Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Security Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Input Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:52:52 --> Language Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Loader Class Initialized
DEBUG - 2013-12-06 00:52:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:52:52 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Config Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:52:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:52:53 --> URI Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Router Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Output Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Security Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Input Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:52:53 --> Language Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Loader Class Initialized
DEBUG - 2013-12-06 00:52:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:52:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Config Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:53:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:53:02 --> URI Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Router Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Output Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Security Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Input Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:53:02 --> Language Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Loader Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:53:02 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:53:02 --> Controller Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Config Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:55:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:55:26 --> URI Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Router Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Output Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Security Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Input Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:55:26 --> Language Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Loader Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:55:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:55:26 --> Controller Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Config Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:55:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:55:34 --> URI Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Router Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Output Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Security Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Input Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:55:34 --> Language Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Loader Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:55:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:55:34 --> Controller Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Config Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:57:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:57:19 --> URI Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Router Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Output Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Security Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Input Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:57:19 --> Language Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Loader Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:57:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:57:19 --> Controller Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Config Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:57:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:57:20 --> URI Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Router Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Output Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Security Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Input Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:57:20 --> Language Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Loader Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:57:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Controller Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Config Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:57:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:57:20 --> URI Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Router Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Output Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Security Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Input Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:57:20 --> Language Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Loader Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:57:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Controller Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Config Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:57:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:57:20 --> URI Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Router Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Output Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Security Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Input Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:57:20 --> Language Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Loader Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:57:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:57:20 --> Controller Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Config Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:57:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:57:21 --> URI Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Router Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Output Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Security Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Input Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:57:21 --> Language Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Loader Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:57:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:57:21 --> Controller Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Config Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:58:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:58:06 --> URI Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Router Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Output Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Security Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Input Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:58:06 --> Language Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Loader Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:58:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Controller Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Config Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:58:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:58:06 --> URI Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Router Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Output Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Security Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Input Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:58:06 --> Language Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Loader Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:58:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:58:06 --> Controller Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Config Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:59:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:59:12 --> URI Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Router Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Output Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Security Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Input Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:59:12 --> Language Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Loader Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:59:12 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:59:12 --> Controller Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Config Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:59:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:59:13 --> URI Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Router Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Output Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Security Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Input Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:59:13 --> Language Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Loader Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:59:13 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Controller Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Config Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:59:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:59:13 --> URI Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Router Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Output Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Security Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Input Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:59:13 --> Language Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Loader Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:59:13 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Controller Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Config Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Hooks Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Utf8 Class Initialized
DEBUG - 2013-12-06 00:59:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 00:59:13 --> URI Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Router Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Output Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Security Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Input Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 00:59:13 --> Language Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Loader Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Helper loaded: url_helper
DEBUG - 2013-12-06 00:59:13 --> Database Driver Class Initialized
DEBUG - 2013-12-06 00:59:13 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:33 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:33 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:33 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:33 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:34 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:34 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:34 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:34 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:34 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:34 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:34 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:35 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:35 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:35 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:38 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:38 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:38 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:38 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:39 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:39 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:39 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:39 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:39 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:40 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:40 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:40 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:41 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:41 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:41 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:57 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:57 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:57 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:57 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:58 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:58 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:58 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:58 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:58 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:59 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:59 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:59 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Controller Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Config Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:00:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:00:59 --> URI Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Router Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Output Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Security Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Input Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:00:59 --> Language Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Loader Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:00:59 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:00:59 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:20 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:25 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:25 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:25 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:25 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:25 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:32 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:32 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:32 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:32 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:35 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:35 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:35 --> Controller Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Config Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:01:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:01:37 --> URI Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Router Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Output Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Security Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Input Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:01:37 --> Language Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Loader Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:01:37 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:01:37 --> Controller Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Config Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:02:15 --> URI Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Router Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Output Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Security Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Input Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:02:15 --> Language Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Loader Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:02:15 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Controller Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Config Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:02:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:02:15 --> URI Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Router Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Output Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Security Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Input Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:02:15 --> Language Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Loader Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:02:15 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:02:15 --> Controller Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Config Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:02:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:02:16 --> URI Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Router Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Output Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Security Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Input Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:02:16 --> Language Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Loader Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:02:16 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:02:16 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:17 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:17 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:17 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:17 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:17 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:17 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:17 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:18 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:18 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:18 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:18 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:18 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:18 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:18 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:18 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:18 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:18 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:18 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:18 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:18 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:18 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:19 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:19 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:19 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:19 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:19 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:19 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:19 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:19 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:19 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:19 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:20 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:54 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:54 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:54 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:54 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:54 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:54 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:54 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:54 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:54 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:54 --> Controller Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Config Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:05:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:05:55 --> URI Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Router Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Output Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Security Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Input Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:05:55 --> Language Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Loader Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:05:55 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:05:55 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:08 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:08 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:08 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:08 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:09 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:09 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:09 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:09 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:48 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:48 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:48 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:48 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:48 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:49 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:49 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:49 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:53 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:53 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Controller Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Config Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:06:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:06:53 --> URI Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Router Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Output Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Security Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Input Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:06:53 --> Language Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Loader Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:06:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:06:53 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:10 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:10 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:10 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:10 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:10 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:11 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:11 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:11 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:11 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:11 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:11 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:11 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:11 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:11 --> Controller Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Config Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:10:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:10:12 --> URI Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Router Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Output Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Security Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Input Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:10:12 --> Language Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Loader Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:10:12 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:10:12 --> Controller Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Config Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:15:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:15:52 --> URI Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Router Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Output Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Security Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Input Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:15:52 --> Language Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Loader Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:15:52 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:15:52 --> Controller Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Config Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:16:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:16:25 --> URI Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Router Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Output Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Security Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Input Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:16:25 --> Language Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Loader Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:16:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:16:25 --> Controller Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Config Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:16:26 --> URI Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Router Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Output Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Security Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Input Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:16:26 --> Language Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Loader Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:16:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Controller Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Config Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:16:26 --> URI Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Router Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Output Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Security Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Input Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:16:26 --> Language Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Loader Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:16:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Controller Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Config Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:16:26 --> URI Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Router Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Output Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Security Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Input Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:16:26 --> Language Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Loader Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:16:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:16:26 --> Controller Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Config Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:16:29 --> URI Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Router Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Output Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Security Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Input Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:16:29 --> Language Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Loader Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:16:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:16:29 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:33 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:33 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:33 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:33 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:34 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:34 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:34 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:34 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:34 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:35 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:35 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:35 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:35 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Controller Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Config Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:18:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:18:35 --> URI Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Router Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Output Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Security Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Input Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:18:35 --> Language Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Loader Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:18:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:18:35 --> Controller Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:20 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:20 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:21 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:21 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:21 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:21 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:26 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:26 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Loader Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:19:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:19:26 --> Controller Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:27 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:27 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Loader Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:19:27 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Controller Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:27 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:27 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Loader Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:19:27 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:19:27 --> Controller Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Config Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:19:37 --> URI Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Router Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Output Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Security Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Input Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:19:37 --> Language Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Loader Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:19:37 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:19:37 --> Controller Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Config Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:20:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:20:15 --> URI Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Router Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Output Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Security Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Input Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:20:15 --> Language Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Loader Class Initialized
DEBUG - 2013-12-06 01:20:15 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:20:15 --> Database Driver Class Initialized
ERROR - 2013-12-06 01:20:15 --> Severity: Notice  --> Array to string conversion /home/alex/web/listslider/server/system/core/Loader.php 233
DEBUG - 2013-12-06 01:20:15 --> Controller Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Config Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:20:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:20:47 --> URI Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Router Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Output Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Security Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Input Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:20:47 --> Language Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Loader Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:20:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Controller Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Config Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:20:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:20:47 --> URI Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Router Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Output Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Security Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Input Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:20:47 --> Language Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Loader Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:20:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:20:47 --> Controller Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Config Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:20:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:20:48 --> URI Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Router Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Output Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Security Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Input Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:20:48 --> Language Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Loader Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:20:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Controller Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Config Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:20:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:20:48 --> URI Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Router Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Output Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Security Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Input Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:20:48 --> Language Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Loader Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:20:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:20:48 --> Controller Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Config Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:21:11 --> URI Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Router Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Output Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Security Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Input Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:21:11 --> Language Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Loader Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:21:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:21:11 --> Controller Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Config Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Hooks Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Utf8 Class Initialized
DEBUG - 2013-12-06 01:21:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 01:21:12 --> URI Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Router Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Output Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Security Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Input Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 01:21:12 --> Language Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Loader Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Helper loaded: url_helper
DEBUG - 2013-12-06 01:21:12 --> Database Driver Class Initialized
DEBUG - 2013-12-06 01:21:12 --> Controller Class Initialized
