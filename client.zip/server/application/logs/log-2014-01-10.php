<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-10 23:05:35 --> Config Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:05:35 --> URI Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Router Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Output Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Security Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Input Class Initialized
DEBUG - 2014-01-10 23:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:05:35 --> Language Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Config Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:06:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:06:05 --> URI Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Router Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Output Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Security Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Input Class Initialized
DEBUG - 2014-01-10 23:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:06:05 --> Language Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Config Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:07:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:07:08 --> URI Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Router Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Output Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Security Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Input Class Initialized
DEBUG - 2014-01-10 23:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:07:08 --> Language Class Initialized
ERROR - 2014-01-10 23:07:08 --> Severity: Warning  --> require(application//libraries/API_Controller.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 4
DEBUG - 2014-01-10 23:08:17 --> Config Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:08:17 --> URI Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Router Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Output Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Security Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Input Class Initialized
DEBUG - 2014-01-10 23:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:08:17 --> Language Class Initialized
ERROR - 2014-01-10 23:08:17 --> Severity: Warning  --> require(../libraries/data_transfer/DataTransfer.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/core/MY_Controller.php 3
DEBUG - 2014-01-10 23:08:38 --> Config Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:08:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:08:38 --> URI Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Router Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Output Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Security Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Input Class Initialized
DEBUG - 2014-01-10 23:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:08:38 --> Language Class Initialized
ERROR - 2014-01-10 23:08:38 --> Severity: Warning  --> require_once(../libraries/data_transfer/DataTransfer.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/core/MY_Controller.php 3
DEBUG - 2014-01-10 23:09:35 --> Config Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:09:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:09:35 --> URI Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Router Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Output Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Security Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Input Class Initialized
DEBUG - 2014-01-10 23:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:09:35 --> Language Class Initialized
ERROR - 2014-01-10 23:09:35 --> Severity: Warning  --> require_once(../libraries/data_transfer/DataTransfer.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/core/MY_Controller.php 3
DEBUG - 2014-01-10 23:09:48 --> Config Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:09:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:09:48 --> URI Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Router Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Output Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Security Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Input Class Initialized
DEBUG - 2014-01-10 23:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:09:48 --> Language Class Initialized
ERROR - 2014-01-10 23:09:48 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:41 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:41 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:41 --> Language Class Initialized
ERROR - 2014-01-10 23:10:41 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:42 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:42 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:42 --> Language Class Initialized
ERROR - 2014-01-10 23:10:42 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:42 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:42 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:42 --> Language Class Initialized
ERROR - 2014-01-10 23:10:42 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:42 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:42 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:42 --> Language Class Initialized
ERROR - 2014-01-10 23:10:42 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:42 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:42 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:42 --> Language Class Initialized
ERROR - 2014-01-10 23:10:42 --> Severity: Warning  --> require_once(../libraries/SmartyParams.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/controllers/todo.php 3
DEBUG - 2014-01-10 23:10:53 --> Config Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:10:53 --> URI Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Router Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Output Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Security Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Input Class Initialized
DEBUG - 2014-01-10 23:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:10:53 --> Language Class Initialized
ERROR - 2014-01-10 23:10:53 --> Severity: Warning  --> require_once(../libraries/REST_Controller.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/core/API_Controller.php 3
DEBUG - 2014-01-10 23:11:12 --> Config Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:11:12 --> URI Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Router Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Output Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Security Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Input Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:11:12 --> Language Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Loader Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:11:12 --> Controller Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:11:12 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:12 --> Model Class Initialized
ERROR - 2014-01-10 23:11:12 --> Severity: Warning  --> require_once(../libraries/data_transfer/DataTransfer.php): failed to open stream: No such file or directory /home/master/Projects/www/kreantis/listslider/server/application/core/MY_Controller.php 28
DEBUG - 2014-01-10 23:11:26 --> Config Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:11:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:11:26 --> URI Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Router Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Output Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Security Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Input Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:11:26 --> Language Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Loader Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:11:26 --> Controller Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:11:26 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:11:26 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:11:26 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Model Class Initialized
DEBUG - 2014-01-10 23:11:26 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Config Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:12:02 --> URI Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Router Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Output Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Security Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Input Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:12:02 --> Language Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Loader Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:12:02 --> Controller Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:12:02 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:02 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Config Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:12:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:12:10 --> URI Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Router Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Output Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Security Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Input Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:12:10 --> Language Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Loader Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:12:10 --> Controller Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:12:10 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:12:10 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:12:10 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:10 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Config Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:12:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:12:40 --> URI Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Router Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Output Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Security Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Input Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:12:40 --> Language Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Loader Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:12:40 --> Controller Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:12:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:12:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:12:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Config Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:12:54 --> URI Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Router Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Output Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Security Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Input Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:12:54 --> Language Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Loader Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:12:54 --> Controller Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:12:54 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:12:54 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:12:54 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Model Class Initialized
DEBUG - 2014-01-10 23:12:54 --> Model Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Config Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:13:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:13:15 --> URI Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Router Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Output Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Security Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Input Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:13:15 --> Language Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Loader Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:13:15 --> Controller Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:13:15 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:13:15 --> Model Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:13:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:13:15 --> Model Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Model Class Initialized
DEBUG - 2014-01-10 23:13:15 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Config Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:14:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:14:35 --> URI Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Router Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Output Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Security Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Input Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:14:35 --> Language Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Loader Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:14:35 --> Controller Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:14:35 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:14:35 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:14:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:14:35 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:35 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Config Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:14:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:14:42 --> URI Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Router Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Output Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Security Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Input Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:14:42 --> Language Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Loader Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:14:42 --> Controller Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:14:42 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:14:42 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:42 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:14:42 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Config Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:14:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:14:49 --> URI Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Router Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Output Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Security Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Input Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:14:49 --> Language Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Loader Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:14:49 --> Controller Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:14:49 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:14:49 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:49 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:14:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:14:49 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Config Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:14:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:14:50 --> URI Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Router Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Output Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Security Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Input Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:14:50 --> Language Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Loader Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:14:50 --> Controller Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:14:50 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:14:50 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:50 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:14:50 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Config Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:14:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:14:53 --> URI Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Router Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Output Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Security Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Input Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:14:53 --> Language Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Loader Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:14:53 --> Controller Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:14:53 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:14:53 --> Model Class Initialized
DEBUG - 2014-01-10 23:14:53 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:14:53 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:03 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:03 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:03 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:03 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:03 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:03 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:03 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:24 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:24 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:24 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:24 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:24 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:24 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:24 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:31 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:31 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:31 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:31 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:31 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:31 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:31 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:36 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:36 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:36 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:36 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:36 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:36 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:36 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:38 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:38 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:38 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:38 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:38 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:38 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:38 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:38 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:38 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:38 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Config Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:15:40 --> URI Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Router Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Output Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Security Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Input Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:15:40 --> Language Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Loader Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:15:40 --> Controller Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:15:40 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:15:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:15:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:15:40 --> Model Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Config Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:16:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:16:17 --> URI Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Router Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Output Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Security Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Input Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:16:17 --> Language Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Loader Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:16:17 --> Controller Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:16:17 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:16:17 --> Model Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:16:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:16:17 --> Model Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Model Class Initialized
DEBUG - 2014-01-10 23:16:17 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Config Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:23:52 --> URI Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Router Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Output Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Security Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Input Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:23:52 --> Language Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Loader Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:23:52 --> Controller Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:23:52 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:23:52 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:23:52 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:52 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Config Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Hooks Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Utf8 Class Initialized
DEBUG - 2014-01-10 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-10 23:23:55 --> URI Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Router Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Output Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Security Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Input Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-10 23:23:55 --> Language Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Loader Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Helper loaded: dump_helper
DEBUG - 2014-01-10 23:23:55 --> Controller Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Config file loaded: application/config/rest.php
DEBUG - 2014-01-10 23:23:55 --> Helper loaded: inflector_helper
DEBUG - 2014-01-10 23:23:55 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Database Driver Class Initialized
ERROR - 2014-01-10 23:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/master/Projects/www/kreantis/listslider/server/system/database/drivers/mysql/mysql_driver.php 91
DEBUG - 2014-01-10 23:23:55 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Model Class Initialized
DEBUG - 2014-01-10 23:23:55 --> Model Class Initialized
