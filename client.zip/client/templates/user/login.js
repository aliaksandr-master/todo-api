define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"user-login\">User Login<form action=\"/server/user/login/\" method=\"POST\"><br><div class=\"input-group\"><span class=\"input-group-addon\">login</span><input type=\"text\" name=\"username\" class=\"form-control\" placeholder=\"Username\"></div><br><div class=\"input-group\"><span class=\"input-group-addon\">password</span><input type=\"password\" name=\"password\" class=\"form-control\" placeholder=\"Password\"></div><br><button type=\"submit\" class=\"login-submit btn btn-success\">Submit</button></form></div>";
  })

});