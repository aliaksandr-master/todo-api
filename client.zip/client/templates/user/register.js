define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"user-register\">User Register<form action=\"/server/user/register/\"><div class=\"input-group\"><span class=\"input-group-addon\">Username</span><input type=\"text\" name=\"username\" class=\"form-control\"></div><br><div class=\"input-group\"><span class=\"input-group-addon\">Email</span><input type=\"text\" name=\"email\" class=\"form-control\"></div><br><div class=\"input-group\"><span class=\"input-group-addon\">Password</span><input type=\"password\" name=\"password\" class=\"form-control\"></div><br><div class=\"input-group\"><span class=\"input-group-addon\">Confirm Password</span><input type=\"password\" name=\"confirm_password\" class=\"form-control\"></div><br><button type=\"submit\" class=\"btn btn-success register-submit\">Send</button><br><br><div class=\"alert alert-success\"></div></form></div>";
  })

});