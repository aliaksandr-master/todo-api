define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"main-wr\"><div class=\"main-menu\"><div class=\"main-menu-head\"><a href=\"#\" class=\"btn btn-default main-menu-head-btn\"><span class=\"glyphicon glyphicon-align-justify\"></span><span class=\"glyphicon glyphicon-remove\"></span></a></div><ul class=\"main-menu-l\"><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/\">Home</a></li><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/about/\">About</a></li><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/user/login/\">User Login</a></li><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/user/register/\">User Register</a></li><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/user/profile/\">User Profile</a></li><li class=\"main-menu-li\"><a class=\"main-menu-li-a\" href=\"/todo/\">Todo Lists</a></li></ul></div><div class=\"main\"><div class=\"main-header\"><div class=\"main-header-user-wr\"><a href=\"#\" class=\"btn btn-default main-header-user-btn\"><span class=\"glyphicon glyphicon-user\"></span></a></div><div class=\"main-header-nav\"></div></div><div class=\"main-wrapper\"><div class=\"main-content\"></div></div></div></div>";
  })

});