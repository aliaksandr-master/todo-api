define(function(require, exports, module){
    "use strict";

	var $ = require('jquery');
	require('css!styles/index');
	require('css!styles/layouts/simple');

	var template = require('templates/layouts/simple');
	var BaseView = require('views/base/view');

    var LayoutView = BaseView.extend({

		container: 'body',

		regions:{
			'main': '.main-content',
			'main-title': '.main-header-title'
		},

		template: template

	});

	template = null;
    return LayoutView;
});