define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"user-profile\"><div class=\"text-center user-profile-logout-wr\"><a href=\"/user/logout/\" class=\"btn btn-default btn-lg user-profile-logout\"><span class=\"glyphicon glyphicon-remove-circle\"></span>&nbsp;&nbsp;LOG OUT</a></div></div>";
  })

});