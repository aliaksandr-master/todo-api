define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  return " checked=\"checked\"";
  }

  buffer += "<div class=\"modal-content\"><div class=\"modal-header\"><button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button><h4 class=\"modal-title\"><input id=\"todo-list-item-chk\" class=\"chk todo-list-item-done-chk\" type=\"checkbox\" value=\"1\"";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.done), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "/><label for=\"todo-list-item-chk\" class=\"todo-list-item-done\">Done</label></h4></div><div class=\"modal-body\"><textarea placeholder=\"Comment\" class=\"todo-list-item-title form-control\">";
  if (stack1 = helpers.title) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.title); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "</textarea></div><div class=\"modal-footer clearfix\"><button class=\"todo-li-btn-remove pull-left btn btn-default\" data-dismiss=\"modal\"><span class=\"glyphicon glyphicon-remove\"></span>&nbsp;&nbsp;Remove</button><button class=\"btn btn-danger pull-right todo-list-item-save\" data-dismiss=\"modal\">Close</button></div></div>";
  return buffer;
  })

});