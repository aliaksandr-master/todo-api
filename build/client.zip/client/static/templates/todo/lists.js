define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"todo-lists\"><div class=\"text-center todo-lists-add-btn-wr\"><a href=\"/todo/create/\" class=\"todo-lists-add-btn btn btn-danger btn-lg\"><span class=\"glyphicon glyphicon-list-alt\"></span>&nbsp;&nbsp;Create List</a></div><ul class=\"todo-lists-l\"></ul></div>";
  })

});