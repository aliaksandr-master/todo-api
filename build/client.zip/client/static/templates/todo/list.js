define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, stack2, self=this, functionType="function", escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  return " active";
  }

function program3(depth0,data) {
  
  var stack1, stack2;
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.active), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack2 || stack2 === 0) { return stack2; }
  else { return ''; }
  }

function program5(depth0,data) {
  
  
  return " class=\"active\"";
  }

function program7(depth0,data) {
  
  var buffer = "";
  return buffer;
  }

function program9(depth0,data) {
  
  var stack1, stack2;
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.active), {hash:{},inverse:self.program(5, program5, data),fn:self.program(7, program7, data),data:data});
  if(stack2 || stack2 === 0) { return stack2; }
  else { return ''; }
  }

  buffer += "<div class=\"todo-list\"><div class=\"todo-list-line\"></div><div class=\"todo-list-head\"><div class=\"todo-list-title-wr\"><input type=\"text\" class=\"-click2edit form-control todo-list-title\" placeholder=\"Tasks List Name\" value=\"";
  if (stack1 = helpers.title) { stack1 = stack1.call(depth0, {hash:{},data:data}); }
  else { stack1 = (depth0 && depth0.title); stack1 = typeof stack1 === functionType ? stack1.call(depth0, {hash:{},data:data}) : stack1; }
  buffer += escapeExpression(stack1)
    + "\"/></div><div class=\"input-group todo-list-task-input-wr\"><div class=\"input-group-btn\"><button type=\"button\" class=\"btn btn-default todo-list-filter-main-btn dropdown-toggle";
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.done), {hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "\" data-toggle=\"dropdown\"><span class=\"glyphicon glyphicon-filter\"></span>&nbsp;&nbsp;<span class=\"caret\"></span></button><ul class=\"dropdown-menu\" role=\"menu\"><li";
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.active), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "><a class=\"todo-list-filter-btn\" data-filter=\"active\" href=\"#\">Active Only</a></li><li";
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.done), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "><a class=\"todo-list-filter-btn\" data-filter=\"done\" href=\"#\">Done Only</a></li><li class=\"divider\"></li><li";
  stack2 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0._prop)),stack1 == null || stack1 === false ? stack1 : stack1.filter)),stack1 == null || stack1 === false ? stack1 : stack1.done), {hash:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),data:data});
  if(stack2 || stack2 === 0) { buffer += stack2; }
  buffer += "><a class=\"todo-list-filter-btn\" data-filter=\"all\" href=\"#\">All</a></li></ul></div><input type=\"text\" class=\"form-control todo-list-input-add\"  placeholder=\"Add new task here...\"><div class=\"input-group-btn\"><button type=\"button\" class=\"btn btn-primary todo-list-input-add-submit\"><span class=\"glyphicon glyphicon-plus\"></span>&nbsp;ADD</button></div></div></div><div class=\"todo-list-body\"><ul class=\"todo-list-l\"></ul></div><div class=\"modal fade\"><div class=\"modal-dialog\"></div></div></div>";
  return buffer;
  })

});