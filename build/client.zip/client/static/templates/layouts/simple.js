define(['handlebars'], function(Handlebars) {

return Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"main-wr\"><nav class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\"><div class=\"container-fluid\"><div class=\"collapse navbar-collapse pull-right\" id=\"bs-example-navbar-collapse-6\"><ul class=\"nav navbar-nav\"><li><a href=\"/\"><span class=\"glyphicon glyphicon-list-alt\"></span>&nbsp;&nbsp;Lists</a></li><li><a href=\"/user/profile/\"><span class=\"glyphicon glyphicon-user\"></span>&nbsp;&nbsp;Profile</a></li></ul></div><div class=\"navbar-header\"><button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-6\"><span class=\"sr-only\">Toggle navigation</span><span class=\"icon-bar\"></span><span class=\"icon-bar\"></span><span class=\"icon-bar\"></span></button><div class=\"navbar-brand main-header-title\"><a href=\"/about/\">ListSlider</a></div></div></div></nav><div class=\"main\"><div class=\"main-header\"></div><div class=\"main-wrapper\"><div class=\"main-content\"></div></div></div></div>";
  })

});