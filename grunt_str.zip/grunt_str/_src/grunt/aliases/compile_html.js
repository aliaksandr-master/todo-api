module.exports = [

	'copy:html',
	'htmlmin:typicalMin',

	'replace:indexReplaceResourceVersion'
];