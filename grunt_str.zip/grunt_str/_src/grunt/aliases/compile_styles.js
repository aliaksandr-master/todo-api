module.exports = [

	'clean:styles',
	'copy:styles',
	'less:compile',
	'sass:compile',
	'copy:fonts',
	'replace:fonts'

];