module.exports = [

	'compile_pictures',
	'compile_styles',
	'compile_html',
	'compile_scripts',
	'compile_templates'

];