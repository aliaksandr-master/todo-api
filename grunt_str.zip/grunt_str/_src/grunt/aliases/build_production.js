module.exports = [
	'install',
	'build',
	'copy:env_production',
	'cssmin:env_production',
	'uglify:env_production'
];