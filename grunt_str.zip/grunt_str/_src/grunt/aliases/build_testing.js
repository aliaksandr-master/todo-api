module.exports = [
	'default'
];