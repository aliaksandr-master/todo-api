module.exports = [

	'clean:templates',
	'handlebars:compile'

];