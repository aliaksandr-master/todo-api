module.exports = [

	'build'

];