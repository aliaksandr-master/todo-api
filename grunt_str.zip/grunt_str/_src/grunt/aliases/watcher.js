module.exports = [

	'build',
	'replace:livereload',
	'watch'
];