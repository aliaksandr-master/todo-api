module.exports = [

	'jshint:check',
	'clean:scripts',
	'copy:scripts',
	'coffee:compile',
	'typescript:compile',

	'replace:matchConfigFromAnywhere'

];