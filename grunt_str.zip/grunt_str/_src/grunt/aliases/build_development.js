module.exports = [
	'build'
];