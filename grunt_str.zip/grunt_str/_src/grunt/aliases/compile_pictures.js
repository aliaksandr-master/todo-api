module.exports = [

	'clean:pictures',
	'copy:pictures'

];