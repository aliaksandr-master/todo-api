module.exports = [
	'clean:all',
	'bower:install',
	'copy:vendors'
];