"use strict";
module.exports = function(grunt){

	return {
		dev: {
			src: "client/js/app.js",
			dest: "client/js/app.js",
			options: {}
		}
	};

};