"use strict";
module.exports = function(grunt){

	return {
		styles: {

		}
	};
};